# 🚀 Quick Start Guide - ABHAY.AI

Get your mining monitoring dashboard up and running in 5 minutes!

---

## Step 1: Run Database Scripts (2 minutes)

1. Look for the **Scripts** folder in your file tree
2. Execute these scripts **in order**:
   - ✅ `001_create_alerts_table.sql`
   - ✅ `002_create_thresholds_table.sql`
   - ✅ `003_create_ml_predictions_table.sql`

**How to run scripts:**
- Click on each script file
- Click the "Run" button
- Wait for "Success" message
- Move to next script

---

## Step 2: Verify Environment Variables (1 minute)

Check the **Vars** section in the sidebar. You should see:

**Required (Already Set):**
- ✅ SUPABASE_URL
- ✅ NEXT_PUBLIC_SUPABASE_URL
- ✅ SUPABASE_ANON_KEY
- ✅ NEXT_PUBLIC_SUPABASE_ANON_KEY

**Optional (For SMS/Email):**
- TWILIO_ACCOUNT_SID
- TWILIO_AUTH_TOKEN
- TWILIO_PHONE_NUMBER
- ADMIN_PHONE_NUMBER
- EMAIL_USER
- EMAIL_PASSWORD
- ADMIN_EMAIL

> **Note:** SMS and Email are optional. The system works without them in simulation mode.

---

## Step 3: Deploy (1 minute)

1. Click **Publish** button (top-right corner)
2. Follow deployment prompts
3. Wait for deployment to complete
4. Click the deployed URL

---

## Step 4: Initialize Thresholds (1 minute)

1. Go to **Excel Upload** page in the dashboard
2. Click **Download Template**
3. (Optional) Edit values if desired
4. Click **Choose CSV File**
5. Select the template file
6. Click Upload
7. Wait for "Success" message

**Default thresholds are now loaded!**

---

## Step 5: Test the System (30 seconds)

1. Go to **Status Panel**
2. Select "Bench 1"
3. For "Vibration" sensor, enter: **60**
4. Click **Submit Reading**
5. You should see:
   - ✅ Red alert modal popup
   - ✅ Notification badge in navbar
   - ✅ Alert in Notifications page
   - ✅ Activity in Home page
   - ✅ ML prediction logged

**Congratulations! Your system is working!** 🎉

---

## What's Next?

### Explore Features
- 📊 **Home** - Overview dashboard
- 🎯 **Status Panel** - Enter sensor readings
- 🤖 **AI Model** - View/edit thresholds
- 🧠 **ML Predictions** - AI risk analysis
- 📋 **Excel Upload** - Bulk threshold updates
- 🔔 **Notifications** - Alert history
- ⚙️ **Settings** - Change language

### Configure SMS (Optional)

1. Sign up for [Twilio](https://www.twilio.com/)
2. Get your Account SID and Auth Token
3. Buy a phone number
4. Add to Vars section:
   \`\`\`
   TWILIO_ACCOUNT_SID=your_sid
   TWILIO_AUTH_TOKEN=your_token
   TWILIO_PHONE_NUMBER=+1234567890
   ADMIN_PHONE_NUMBER=+1234567890
   \`\`\`
5. Test with a Medium/Critical alert

### Configure Email (Optional)

1. Use Gmail or any SMTP provider
2. Generate an app password ([Gmail Instructions](https://support.google.com/accounts/answer/185833))
3. Add to Vars section:
   \`\`\`
   EMAIL_USER=your_email@gmail.com
   EMAIL_PASSWORD=your_app_password
   ADMIN_EMAIL=admin@yourcompany.com
   \`\`\`
4. Test with a Medium/Critical alert

---

## Common First-Time Issues

### "No thresholds found"
**Solution:** Upload the template CSV from Excel Upload page

### "Alerts not showing"
**Solution:** Check that all 3 SQL scripts were executed successfully

### "SMS/Email not sending"
**Solution:** This is normal! Configure credentials or continue in simulation mode

### "Real-time updates not working"
**Solution:** Refresh the page and ensure Supabase Realtime is enabled

---

## Need Help?

1. Check the main `README.md` for detailed documentation
2. Review `ML_EXCEL_SYSTEM_GUIDE.md` for ML and Excel features
3. Check `ALERT_SYSTEM_SETUP.md` for alert configuration
4. Look at browser console (F12) for error messages

---

## Testing Checklist

- [ ] Can submit sensor readings
- [ ] Alerts appear in Notifications
- [ ] Navbar badge updates
- [ ] Home page shows recent activity
- [ ] ML Predictions page shows data
- [ ] Can switch languages in Settings
- [ ] Can upload CSV thresholds
- [ ] Dark mode works

---

**You're all set! Start monitoring your mine safely!** ⛏️

**Time to Complete:** ~5 minutes  
**Difficulty:** Easy  
**Support:** Check README.md for detailed docs
