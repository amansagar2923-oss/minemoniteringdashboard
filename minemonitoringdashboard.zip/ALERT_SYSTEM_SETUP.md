# Alert System Setup Guide

## Overview

This mining monitoring dashboard includes a complete alert system with:

- ✅ **Database Storage** - Alerts saved to Supabase PostgreSQL
- ✅ **Real-time Notifications** - Live updates via Supabase Realtime
- ✅ **Browser Notifications** - Push notifications for critical alerts
- ✅ **SMS Notifications** - Twilio integration for medium/critical alerts
- ✅ **Email Notifications** - Nodemailer integration for critical alerts

## 1. Database Setup

### Create the Alerts Table

The SQL script is already in `scripts/001_create_alerts_table.sql`. Run it to create the database table:

\`\`\`sql
-- This creates the alerts table with proper indexes and RLS policies
\`\`\`

The alerts table includes:
- `id` - Unique identifier (UUID)
- `sensor_name` - Name of the sensor
- `sensor_value` - Current reading value
- `threshold` - Threshold value for comparison
- `severity` - Alert level (normal, medium, critical)
- `message` - Alert message
- `read` - Whether the alert has been read
- `created_at` - Timestamp

## 2. Environment Variables Setup

Add these environment variables to your Vercel project:

### Required (Already Configured)
- ✅ `SUPABASE_URL` - Your Supabase project URL
- ✅ `NEXT_PUBLIC_SUPABASE_URL` - Same as above (public)
- ✅ `NEXT_PUBLIC_SUPABASE_ANON_KEY` - Supabase anonymous key
- ✅ `SUPABASE_ANON_KEY` - Same as above (server-side)

### Optional: Twilio SMS (for SMS notifications)
- `TWILIO_ACCOUNT_SID` - Your Twilio account SID
- `TWILIO_AUTH_TOKEN` - Your Twilio auth token
- `TWILIO_PHONE_NUMBER` - Your Twilio phone number (e.g., +1234567890)
- `ADMIN_PHONE_NUMBER` - The phone number to receive alerts (e.g., +919876543210)

### Optional: Email (for email notifications)
- `EMAIL_USER` - Your Gmail address (e.g., alerts@yourcompany.com)
- `EMAIL_PASSWORD` - Gmail App Password (not your regular password)
- `ADMIN_EMAIL` - The email address to receive alerts

## 3. Twilio Setup (Optional)

### Steps:
1. Sign up at [twilio.com](https://www.twilio.com/)
2. Get a phone number from the Twilio console
3. Copy your Account SID and Auth Token
4. Add the environment variables to Vercel

### Testing:
Without Twilio credentials, the system will log what SMS would be sent (simulation mode).

## 4. Email Setup (Optional)

### Gmail Setup:
1. Enable 2-Factor Authentication on your Google account
2. Generate an App Password:
   - Go to [myaccount.google.com/security](https://myaccount.google.com/security)
   - Select "2-Step Verification" → "App passwords"
   - Generate a password for "Mail" on "Other device"
3. Use the 16-character App Password as `EMAIL_PASSWORD`

### Testing:
Without email credentials, the system will log what email would be sent (simulation mode).

## 5. How It Works

### Alert Flow:

1. **Sensor Reading Submitted** (in Status Panel)
   - User enters sensor value
   - System calculates severity:
     - `< 50% threshold` → Normal (Green)
     - `50% - 100% threshold` → Medium (Yellow)
     - `> threshold` → Critical (Red)

2. **Alert Saved to Database**
   - POST request to `/api/alerts`
   - Alert stored in Supabase `alerts` table

3. **Notifications Triggered**:
   - **Normal**: Database only
   - **Medium**: Database + SMS (if configured)
   - **Critical**: Database + SMS + Email + Modal popup

4. **Real-time Updates**
   - Supabase Realtime broadcasts new alerts
   - All connected clients receive instant notification
   - Browser notification appears (if permission granted)
   - Notification badge updates in navbar

5. **Viewing Alerts**
   - Navigate to Notifications panel
   - View all alerts with color-coded severity
   - Mark as read or delete alerts

## 6. Browser Notifications

The system requests notification permission on first visit to the Status page.

**To enable:**
- Click "Allow" when prompted
- Or manually enable in browser settings

**Critical alerts** will show browser notifications automatically.

## 7. API Endpoints

### POST `/api/alerts`
Creates a new alert and triggers notifications.

**Request Body:**
\`\`\`json
{
  "sensor_name": "Vibration",
  "sensor_value": 75,
  "threshold": 50,
  "severity": "critical",
  "message": "Vibration reading 75mm/s exceeds threshold 50mm/s"
}
\`\`\`

### GET `/api/alerts`
Fetches all alerts from the database.

**Response:**
\`\`\`json
{
  "alerts": [
    {
      "id": "uuid",
      "sensor_name": "Vibration",
      "sensor_value": 75,
      "threshold": 50,
      "severity": "critical",
      "message": "...",
      "read": false,
      "created_at": "2025-01-15T10:30:00Z"
    }
  ]
}
\`\`\`

## 8. Testing the System

### Test Alert Flow:
1. Go to **Status** page
2. Select a bench
3. Enter a sensor value:
   - **< 25** → Normal (green)
   - **25-50** → Medium (yellow)
   - **> 50** → Critical (red)
4. Click "Submit Reading"
5. Check:
   - Alert appears in **Notifications** page
   - Navbar badge shows unread count
   - Browser notification (for critical)
   - Console logs show SMS/email simulation

## 9. Production Checklist

- [ ] Run database migration script
- [ ] Add Twilio credentials (optional)
- [ ] Add email credentials (optional)
- [ ] Test alert creation in Status panel
- [ ] Verify alerts appear in Notifications panel
- [ ] Check real-time updates work
- [ ] Test browser notifications
- [ ] Monitor console for errors

## 10. Troubleshooting

### Alerts not saving:
- Check Supabase connection
- Verify database table exists
- Check browser console for errors

### Real-time not working:
- Verify Supabase Realtime is enabled
- Check network tab for websocket connection
- Ensure RLS policies allow reads

### SMS not sending:
- Verify Twilio credentials are correct
- Check Twilio account balance
- Review Twilio console for error logs

### Email not sending:
- Verify Gmail App Password is correct
- Check "Less secure app access" is enabled
- Review email logs in console

## Support

For issues, check:
1. Browser console for JavaScript errors
2. Network tab for failed API requests
3. Supabase logs for database errors
4. Vercel logs for server-side errors
