-- Create ML predictions table
CREATE TABLE IF NOT EXISTS ml_predictions (
  id SERIAL PRIMARY KEY,
  sensor_id TEXT NOT NULL,
  sensor_name TEXT NOT NULL,
  input_value NUMERIC NOT NULL,
  predicted_risk TEXT NOT NULL, -- normal, medium, critical
  confidence NUMERIC NOT NULL, -- 0-100%
  recommendation TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_ml_predictions_sensor_id ON ml_predictions(sensor_id);
CREATE INDEX IF NOT EXISTS idx_ml_predictions_created_at ON ml_predictions(created_at DESC);
