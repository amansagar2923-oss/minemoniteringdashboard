-- Create thresholds table for dynamic threshold management
CREATE TABLE IF NOT EXISTS thresholds (
  id SERIAL PRIMARY KEY,
  sensor_id TEXT NOT NULL UNIQUE,
  sensor_name TEXT NOT NULL,
  threshold_value NUMERIC NOT NULL,
  unit TEXT NOT NULL,
  bench_id TEXT NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_thresholds_sensor_id ON thresholds(sensor_id);
CREATE INDEX IF NOT EXISTS idx_thresholds_bench_id ON thresholds(bench_id);

-- Insert default thresholds for all benches
DO $$
DECLARE
  bench_num INTEGER;
BEGIN
  FOR bench_num IN 1..5 LOOP
    INSERT INTO thresholds (sensor_id, sensor_name, threshold_value, unit, bench_id)
    VALUES
      (CONCAT('b', bench_num, '-s1'), 'Vibration', 50, 'mm/s', CONCAT('Bench ', bench_num)),
      (CONCAT('b', bench_num, '-s2'), 'Humidity', 60, '%', CONCAT('Bench ', bench_num)),
      (CONCAT('b', bench_num, '-s3'), 'Temperature', 70, '°C', CONCAT('Bench ', bench_num)),
      (CONCAT('b', bench_num, '-s4'), 'Pore Pressure', 80, 'kPa', CONCAT('Bench ', bench_num))
    ON CONFLICT (sensor_id) DO NOTHING;
  END LOOP;
END $$;
