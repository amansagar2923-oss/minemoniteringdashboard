"use client"

import { useEffect, useRef } from "react"
import * as THREE from "three"

interface Mine3DProps {
  rotation: { x: number; y: number }
  zoom: number
}

export function Mine3D({ rotation, zoom }: Mine3DProps) {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!containerRef.current) return

    const scene = new THREE.Scene()
    scene.background = new THREE.Color(0xf8f7f5)
    scene.fog = new THREE.Fog(0xf8f7f5, 100, 500)

    const camera = new THREE.PerspectiveCamera(
      75,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000,
    )
    camera.position.set(0, 10, 15)
    camera.lookAt(0, 0, 0)

    const renderer = new THREE.WebGLRenderer({ antialias: true })
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight)
    renderer.shadowMap.enabled = true
    renderer.shadowMap.type = THREE.PCFShadowShadowMap
    containerRef.current.appendChild(renderer.domElement)

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6)
    scene.add(ambientLight)

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8)
    directionalLight.position.set(50, 50, 30)
    directionalLight.castShadow = true
    directionalLight.shadow.mapSize.width = 2048
    directionalLight.shadow.mapSize.height = 2048
    directionalLight.shadow.camera.far = 150
    directionalLight.shadow.camera.left = -100
    directionalLight.shadow.camera.right = 100
    directionalLight.shadow.camera.top = 100
    directionalLight.shadow.camera.bottom = -100
    scene.add(directionalLight)

    // Create mine pit (realistic terraced design)
    const createMinePit = () => {
      const group = new THREE.Group()

      // Main pit depression using geometry
      const pitGeometry = new THREE.ConeGeometry(30, 25, 32)
      const pitMaterial = new THREE.MeshStandardMaterial({
        color: 0x8b7355,
        metalness: 0.3,
        roughness: 0.8,
      })
      const pit = new THREE.Mesh(pitGeometry, pitMaterial)
      pit.position.y = -8
      pit.castShadow = true
      pit.receiveShadow = true
      group.add(pit)

      // Benches (terraced levels)
      for (let i = 0; i < 5; i++) {
        const benchGeometry = new THREE.CylinderGeometry(25 - i * 4, 22 - i * 4, 3, 32)
        const benchColor = i % 2 === 0 ? 0x7a6b52 : 0x8b7355
        const benchMaterial = new THREE.MeshStandardMaterial({
          color: benchColor,
          metalness: 0.2,
          roughness: 0.9,
        })
        const bench = new THREE.Mesh(benchGeometry, benchMaterial)
        bench.position.y = -5 + i * 4
        bench.castShadow = true
        bench.receiveShadow = true
        group.add(bench)
      }

      // Ground/rim
      const rimGeometry = new THREE.CylinderGeometry(40, 40, 2, 32)
      const rimMaterial = new THREE.MeshStandardMaterial({
        color: 0x9d8b6f,
        metalness: 0.1,
        roughness: 0.95,
      })
      const rim = new THREE.Mesh(rimGeometry, rimMaterial)
      rim.position.y = 0
      rim.castShadow = true
      rim.receiveShadow = true
      group.add(rim)

      // Equipment/structures
      const createEquipment = (x: number, z: number, color: number) => {
        const eqGeometry = new THREE.BoxGeometry(4, 6, 4)
        const eqMaterial = new THREE.MeshStandardMaterial({
          color,
          metalness: 0.6,
          roughness: 0.4,
        })
        const eq = new THREE.Mesh(eqGeometry, eqMaterial)
        eq.position.set(x, 3, z)
        eq.castShadow = true
        eq.receiveShadow = true
        group.add(eq)
      }

      createEquipment(-20, -15, 0xc0bbb3)
      createEquipment(20, -15, 0xc0bbb3)
      createEquipment(0, -25, 0xd4af37)

      return { group, pitGeometry, rimGeometry }
    }

    const { group, pitGeometry, rimGeometry } = createMinePit()
    scene.add(group)

    // Handle window resize
    const handleResize = () => {
      if (!containerRef.current) return
      const width = containerRef.current.clientWidth
      const height = containerRef.current.clientHeight
      camera.aspect = width / height
      camera.updateProjectionMatrix()
      renderer.setSize(width, height)
    }

    window.addEventListener("resize", handleResize)

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate)

      // Update camera based on props
      group.rotation.x = rotation.x
      group.rotation.y = rotation.y

      const distance = 40 / zoom
      camera.position.z = distance
      camera.updateProjectionMatrix()

      renderer.render(scene, camera)
    }

    animate()

    return () => {
      window.removeEventListener("resize", handleResize)
      containerRef.current?.removeChild(renderer.domElement)
      pitGeometry.dispose()
      rimGeometry.dispose()
      renderer.dispose()
    }
  }, [rotation, zoom])

  return <div ref={containerRef} className="w-full h-full" />
}
