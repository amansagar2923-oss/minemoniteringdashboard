"use client"

import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import { useState, useEffect } from "react"
import { Download } from "lucide-react"

interface StatusGraphsProps {
  benchId: string
  sensorValues?: { [key: string]: number }
  updateTrigger?: number
}

export function StatusGraphs({ benchId, sensorValues = {}, updateTrigger = 0 }: StatusGraphsProps) {
  const [graphData, setGraphData] = useState<any[]>([])
  const [forecastData, setForecastData] = useState<any[]>([])

  useEffect(() => {
    const currentTime = new Date()
    const historical = Array.from({ length: 12 }, (_, i) => {
      const time = new Date(currentTime.getTime() - (11 - i) * 5 * 60 * 1000)
      return {
        time: time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        period: `${i < 12 ? "Recent" : "Earlier"}`,
        "Vibration (mm/s)": Math.floor(30 + Math.random() * 40),
        "Humidity (%)": Math.floor(40 + Math.random() * 40),
        "Temperature (°C)": Math.floor(35 + Math.random() * 45),
        "Pore Pressure (kPa)": Math.floor(50 + Math.random() * 30),
        threshold: 70,
      }
    })

    if (Object.keys(sensorValues).length > 0) {
      const latestPoint = historical[historical.length - 1]
      Object.entries(sensorValues).forEach(([key, value]) => {
        if (key.includes("vibration")) latestPoint["Vibration (mm/s)"] = value
        if (key.includes("humidity")) latestPoint["Humidity (%)"] = value
        if (key.includes("temperature")) latestPoint["Temperature (°C)"] = value
        if (key.includes("pore")) latestPoint["Pore Pressure (kPa)"] = value
      })
    }

    const forecast = Array.from({ length: 8 }, (_, i) => ({
      period: `+${i + 1}h`,
      "24h Forecast (mm/s)": Math.floor(50 + Math.random() * 30),
      "48h Forecast (kPa)": Math.floor(45 + Math.random() * 35),
    }))

    setGraphData(historical)
    setForecastData(forecast)
  }, [benchId, sensorValues, updateTrigger])

  const downloadPrediction = () => {
    const timestamp = new Date().toLocaleString()
    const reportDate = new Date().toLocaleDateString()

    const csvContent = [
      ["=".repeat(80)],
      ["OPEN-PIT MINE MONITORING SYSTEM - PREDICTION REPORT"],
      ["=".repeat(80)],
      [""],
      ["Report Generated:", timestamp],
      ["Bench ID:", benchId],
      ["Report Date:", reportDate],
      [""],
      ["=".repeat(80)],
      ["SENSOR READINGS & THRESHOLD ANALYSIS"],
      ["=".repeat(80)],
      [""],
      ["HISTORICAL TRENDS (LAST 24 HOURS)"],
      ["Time", "Vibration (mm/s)", "Humidity (%)", "Temperature (°C)", "Pore Pressure (kPa)", "Threshold", "Status"],
      ...graphData.map((row) => {
        const maxValue = Math.max(
          row["Vibration (mm/s)"],
          row["Humidity (%)"],
          row["Temperature (°C)"],
          row["Pore Pressure (kPa)"],
        )
        const status = maxValue >= row.threshold ? "CRITICAL" : maxValue >= row.threshold * 0.85 ? "MEDIUM" : "NORMAL"
        return [
          row.time,
          row["Vibration (mm/s)"],
          row["Humidity (%)"],
          row["Temperature (°C)"],
          row["Pore Pressure (kPa)"],
          row.threshold,
          status,
        ]
      }),
      [""],
      ["=".repeat(80)],
      ["FORECAST PREDICTION (72 HOURS)"],
      ["=".repeat(80)],
      [""],
      ["Period", "24h Forecast (mm/s)", "48h Forecast (kPa)", "Predicted Status"],
      ...forecastData.map((row) => {
        const maxValue = Math.max(row["24h Forecast (mm/s)"], row["48h Forecast (kPa)"])
        const status = maxValue >= 80 ? "CRITICAL" : maxValue >= 68 ? "MEDIUM" : "NORMAL"
        return [row.period, row["24h Forecast (mm/s)"], row["48h Forecast (kPa)"], status]
      }),
      [""],
      ["=".repeat(80)],
      ["REPORT SUMMARY"],
      ["=".repeat(80)],
      [""],
      ["This report contains:"],
      ["- 24-hour historical sensor readings for all 4 active sensors"],
      ["- 72-hour AI-powered forecast predictions"],
      ["- Status classification (NORMAL/MEDIUM/CRITICAL) for each reading"],
      ["- Threshold comparison analysis"],
      [""],
      ["Recommendations:"],
      ["- Monitor all critical readings immediately"],
      ["- Increase observation frequency for medium-risk zones"],
      ["- Plan preventive maintenance based on forecast trends"],
      ["- Contact emergency services if critical alerts persist"],
      [""],
      ["Report ID:", `${benchId}-${Date.now()}`],
      ["Document Classification:", "OPERATIONAL DATA"],
    ]
      .map((row) => (Array.isArray(row) ? row.map((cell) => `"${cell}"`).join(",") : row))
      .join("\n")

    const element = document.createElement("a")
    element.setAttribute("href", "data:text/csv;charset=utf-8," + encodeURIComponent(csvContent))
    element.setAttribute("download", `${benchId}-prediction-report-${Date.now()}.csv`)
    element.style.display = "none"
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  return (
    <div className="mt-12 space-y-8">
      <div className="flex justify-end">
        <button
          onClick={downloadPrediction}
          className="flex items-center gap-2 px-4 py-2 bg-accent text-accent-foreground rounded-lg hover:opacity-90 transition-opacity"
        >
          <Download size={18} />
          Download Prediction
        </button>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-foreground mb-2">Historical Trends (Last 24 Hours)</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Real-time sensor readings across all 4 active sensors: Vibration, Humidity, Temperature, and Pore Pressure
        </p>
        <div className="bg-card border border-border rounded-lg p-6">
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={graphData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ddd7d0" />
              <XAxis dataKey="time" stroke="#5f5955" />
              <YAxis
                stroke="#5f5955"
                label={{ value: "Reading Value (with units)", angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#ffffff",
                  border: "1px solid #ddd7d0",
                  borderRadius: "8px",
                }}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="Vibration (mm/s)"
                stroke="#d4af37"
                strokeWidth={2}
                name="Vibration (mm/s)"
              />
              <Line type="monotone" dataKey="Humidity (%)" stroke="#8b7355" strokeWidth={2} name="Humidity (%)" />
              <Line
                type="monotone"
                dataKey="Temperature (°C)"
                stroke="#5f5955"
                strokeWidth={2}
                name="Temperature (°C)"
              />
              <Line
                type="monotone"
                dataKey="Pore Pressure (kPa)"
                stroke="#a0826d"
                strokeWidth={2}
                name="Pore Pressure (kPa)"
              />
              <Line
                type="monotone"
                dataKey="threshold"
                stroke="#ef4444"
                strokeWidth={2}
                strokeDasharray="5 5"
                name="Threshold"
              />
            </LineChart>
          </ResponsiveContainer>
          <p className="text-xs text-muted-foreground mt-4 leading-relaxed">
            <strong>Interpretation:</strong> This graph displays the 24-hour trend of all active sensors with their
            respective units. Vibration is measured in mm/s indicating ground movement intensity, Humidity in % showing
            atmospheric moisture, Temperature in °C for environmental conditions, and Pore Pressure in kPa representing
            subsurface water pressure. The red dashed line marks the critical threshold—alert immediately if any sensor
            approaches or exceeds this line. Monitor the correlation between sensors to identify potential safety
            hazards.
          </p>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-foreground mb-2">Forecast Prediction (72 Hours)</h3>
        <p className="text-sm text-muted-foreground mb-4">
          AI-powered predictions for Vibration and Pore Pressure over the next 24 and 48 hours
        </p>
        <div className="bg-card border border-border rounded-lg p-6">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={forecastData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ddd7d0" />
              <XAxis dataKey="period" stroke="#5f5955" />
              <YAxis stroke="#5f5955" label={{ value: "Predicted Value", angle: -90, position: "insideLeft" }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#ffffff",
                  border: "1px solid #ddd7d0",
                  borderRadius: "8px",
                }}
              />
              <Legend />
              <Bar dataKey="24h Forecast (mm/s)" fill="#d4af37" name="24h Forecast (mm/s)" />
              <Bar dataKey="48h Forecast (kPa)" fill="#8b7355" name="48h Forecast (kPa)" />
            </BarChart>
          </ResponsiveContainer>
          <p className="text-xs text-muted-foreground mt-4 leading-relaxed">
            <strong>Interpretation:</strong> This bar chart shows AI-predicted sensor values for the next 24 and 48
            hours based on historical patterns and current conditions. Use this forecast to proactively plan maintenance
            schedules and implement preventive measures before critical thresholds are reached. Rising trends indicate
            increased risk—coordinate with site management for appropriate response actions. Predictions update every
            hour with new data.
          </p>
        </div>
      </div>
    </div>
  )
}
