"use client"

import type { BenchData } from "@/lib/context"

interface BenchSelectorProps {
  benches: BenchData[]
  selectedBench: BenchData
  onSelectBench: (bench: BenchData) => void
}

export function BenchSelector({ benches, selectedBench, onSelectBench }: BenchSelectorProps) {
  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <h3 className="text-sm font-semibold text-foreground mb-3">Select Bench</h3>
      <div className="flex flex-wrap gap-2">
        {benches.map((bench) => (
          <button
            key={bench.id}
            onClick={() => onSelectBench(bench)}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              selectedBench.id === bench.id
                ? "bg-accent text-accent-foreground"
                : "bg-secondary text-foreground hover:bg-muted"
            }`}
          >
            {bench.name}
          </button>
        ))}
      </div>
    </div>
  )
}
