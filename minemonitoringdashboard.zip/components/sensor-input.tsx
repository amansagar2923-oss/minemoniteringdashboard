"use client"

import type React from "react"

import { useState } from "react"
import type { Sensor } from "@/lib/context"
import { AlertCircle, ChevronRight } from "lucide-react"

interface SensorInputProps {
  sensor: Sensor
  benchId: string
  onSubmit: (value: number) => void
}

export function SensorInput({ sensor, benchId, onSubmit }: SensorInputProps) {
  const [value, setValue] = useState("")
  const [error, setError] = useState("")

  const handleSubmit = () => {
    const numValue = Number.parseFloat(value)
    if (isNaN(numValue)) {
      setError("Please enter a valid number")
      return
    }

    onSubmit(numValue)
    setValue("")
    setError("")
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSubmit()
    }
  }

  return (
    <div className="bg-card border border-border rounded-lg p-4 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-semibold text-foreground">{sensor.name}</h4>
        <span className="text-xs bg-accent/10 text-accent px-2 py-1 rounded">
          Threshold: {sensor.threshold} {sensor.unit}
        </span>
      </div>

      <div className="space-y-2">
        <label className="text-xs text-muted-foreground block">Enter reading value ({sensor.unit}):</label>
        <div className="flex gap-2">
          <input
            type="number"
            value={value}
            onChange={(e) => {
              setValue(e.target.value)
              setError("")
            }}
            onKeyPress={handleKeyPress}
            placeholder="0"
            className="flex-1 px-3 py-2 bg-input border border-border rounded-lg text-foreground placeholder-muted-foreground text-sm focus:outline-none focus:ring-1 focus:ring-accent"
          />
          <button
            onClick={handleSubmit}
            className="px-3 py-2 bg-accent text-accent-foreground rounded-lg hover:opacity-90 transition-opacity"
          >
            <ChevronRight size={18} />
          </button>
        </div>
        {error && (
          <p className="text-xs text-red-600 flex items-center gap-1">
            <AlertCircle size={12} />
            {error}
          </p>
        )}
      </div>
    </div>
  )
}
