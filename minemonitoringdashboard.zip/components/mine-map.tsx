"use client"

import { useState } from "react"

interface RiskZone {
  id: string
  name: string
  lat: number
  lng: number
  severity: "safe" | "medium" | "critical"
  value: number
  lastUpdate: string
}

export function MineMap() {
  const [riskZones, setRiskZones] = useState<RiskZone[]>([
    {
      id: "zone-1",
      name: "Bench 1 - North Face",
      lat: 50,
      lng: 40,
      severity: "safe",
      value: 32,
      lastUpdate: "Just now",
    },
    {
      id: "zone-2",
      name: "Bench 2 - East Wall",
      lat: 60,
      lng: 60,
      severity: "medium",
      value: 68,
      lastUpdate: "2 min ago",
    },
    {
      id: "zone-3",
      name: "Bench 3 - South Pit",
      lat: 40,
      lng: 70,
      severity: "critical",
      value: 85,
      lastUpdate: "1 min ago",
    },
    {
      id: "zone-4",
      name: "Bench 4 - Central Zone",
      lat: 45,
      lng: 50,
      severity: "safe",
      value: 28,
      lastUpdate: "3 min ago",
    },
    {
      id: "zone-5",
      name: "Bench 5 - West Area",
      lat: 35,
      lng: 35,
      severity: "medium",
      value: 72,
      lastUpdate: "5 min ago",
    },
  ])

  const getSeverityColor = (severity: "safe" | "medium" | "critical") => {
    switch (severity) {
      case "safe":
        return "bg-green-500"
      case "medium":
        return "bg-yellow-500"
      case "critical":
        return "bg-red-500"
    }
  }

  const getSeverityBorder = (severity: "safe" | "medium" | "critical") => {
    switch (severity) {
      case "safe":
        return "border-green-600"
      case "medium":
        return "border-yellow-600"
      case "critical":
        return "border-red-600"
    }
  }

  return (
    <div className="w-full h-full flex flex-col">
      {/* Map Background */}
      <div className="flex-1 relative bg-gradient-to-br from-secondary to-secondary/50 overflow-hidden">
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice">
          {/* Mine pit outline */}
          <circle cx="50" cy="50" r="45" fill="none" stroke="#ddd7d0" strokeWidth="0.5" opacity="0.5" />
          <circle cx="50" cy="50" r="35" fill="none" stroke="#ddd7d0" strokeWidth="0.3" opacity="0.3" />
          <circle cx="50" cy="50" r="25" fill="none" stroke="#ddd7d0" strokeWidth="0.3" opacity="0.3" />

          {/* Grid pattern */}
          {Array.from({ length: 10 }).map((_, i) => (
            <line
              key={`v${i}`}
              x1={10 + i * 10}
              y1="0"
              x2={10 + i * 10}
              y2="100"
              stroke="#ddd7d0"
              strokeWidth="0.2"
              opacity="0.1"
            />
          ))}
          {Array.from({ length: 10 }).map((_, i) => (
            <line
              key={`h${i}`}
              x1="0"
              y1={10 + i * 10}
              x2="100"
              y2={10 + i * 10}
              stroke="#ddd7d0"
              strokeWidth="0.2"
              opacity="0.1"
            />
          ))}
        </svg>

        {/* Risk zones as interactive boxes */}
        <div className="absolute inset-0">
          {riskZones.map((zone) => (
            <div
              key={zone.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
              style={{
                left: `${zone.lng}%`,
                top: `${zone.lat}%`,
              }}
            >
              {/* Marker dot */}
              <div
                className={`w-4 h-4 rounded-full border-2 ${getSeverityColor(
                  zone.severity,
                )} ${getSeverityBorder(zone.severity)} transition-all group-hover:w-6 group-hover:h-6`}
              />

              {/* Tooltip on hover */}
              <div className="absolute left-6 top-0 bg-card border border-border rounded-lg p-3 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-20">
                <p className="font-semibold text-foreground text-sm">{zone.name}</p>
                <p className="text-muted-foreground text-xs mt-1">Risk Level: {zone.value}%</p>
                <p
                  className={`text-xs mt-1 font-medium ${
                    zone.severity === "safe"
                      ? "text-green-600"
                      : zone.severity === "medium"
                        ? "text-yellow-600"
                        : "text-red-600"
                  }`}
                >
                  {zone.severity.toUpperCase()}
                </p>
                <p className="text-muted-foreground text-xs mt-1">{zone.lastUpdate}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Legend */}
        <div className="absolute bottom-4 left-4 bg-card border border-border rounded-lg p-3 shadow-lg">
          <p className="text-xs font-semibold text-foreground mb-2">Risk Levels</p>
          <div className="space-y-1 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500 border border-green-600" />
              <span className="text-foreground">Safe</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-yellow-500 border border-yellow-600" />
              <span className="text-foreground">Medium Risk</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500 border border-red-600" />
              <span className="text-foreground">Critical</span>
            </div>
          </div>
        </div>
      </div>

      {/* Risk Zones List */}
      <div className="border-t border-border bg-card p-4 max-h-40 overflow-y-auto">
        <h3 className="text-sm font-semibold text-foreground mb-3">Active Zones</h3>
        <div className="space-y-2">
          {riskZones.map((zone) => (
            <div key={zone.id} className="flex items-center justify-between p-2 bg-secondary rounded-lg">
              <div className="flex items-center gap-3">
                <div className={`w-3 h-3 rounded-full ${getSeverityColor(zone.severity)}`} />
                <div>
                  <p className="text-sm font-medium text-foreground">{zone.name}</p>
                  <p className="text-xs text-muted-foreground">{zone.lastUpdate}</p>
                </div>
              </div>
              <span className="text-xs font-semibold text-foreground bg-muted px-2 py-1 rounded">{zone.value}%</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
