"use client"

import { useEffect, useState } from "react"
import { AlertCircle, AlertTriangle, CheckCircle2, X, Clock, Activity, TrendingUp } from "lucide-react"

interface SensorReading {
  sensorId: string
  sensorName: string
  value: number
  threshold: number
  unit: string
}

interface AlertModalProps {
  reading: SensorReading
  severity: "normal" | "medium" | "critical"
  benchName: string
  onClose: () => void
}

export function AlertModal({ reading, severity, benchName, onClose }: AlertModalProps) {
  const [isVisible, setIsVisible] = useState(false)
  const [smsNumber] = useState(() => Math.floor(100000 + Math.random() * 900000).toString())
  const [emailDomain] = useState(() => ["mining.ops", "safety.alert", "control.center"][Math.floor(Math.random() * 3)])

  useEffect(() => {
    setTimeout(() => setIsVisible(true), 50)
  }, [])

  useEffect(() => {
    if (severity === "critical") {
      // Create audio context for beep sound
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)

      oscillator.frequency.value = 880 // High-pitched beep (A5 note)
      oscillator.type = "sine"

      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5)

      oscillator.start(audioContext.currentTime)
      oscillator.stop(audioContext.currentTime + 0.5)

      // Play 3 beeps for critical
      setTimeout(() => {
        const osc2 = audioContext.createOscillator()
        const gain2 = audioContext.createGain()
        osc2.connect(gain2)
        gain2.connect(audioContext.destination)
        osc2.frequency.value = 880
        osc2.type = "sine"
        gain2.gain.setValueAtTime(0.3, audioContext.currentTime)
        gain2.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5)
        osc2.start()
        osc2.stop(audioContext.currentTime + 0.5)
      }, 600)

      setTimeout(() => {
        const osc3 = audioContext.createOscillator()
        const gain3 = audioContext.createGain()
        osc3.connect(gain3)
        gain3.connect(audioContext.destination)
        osc3.frequency.value = 880
        osc3.type = "sine"
        gain3.gain.setValueAtTime(0.3, audioContext.currentTime)
        gain3.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5)
        osc3.start()
        osc3.stop(audioContext.currentTime + 0.5)
      }, 1200)
    }
  }, [severity])

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === "Enter" || e.key === "Escape") {
        setIsVisible(false)
        setTimeout(onClose, 300)
      }
    }
    window.addEventListener("keydown", handleKeyPress)
    return () => window.removeEventListener("keydown", handleKeyPress)
  }, [onClose])

  const getSeverityConfig = (sev: typeof severity) => {
    switch (sev) {
      case "normal":
        return {
          bgGradient: "from-green-500 to-emerald-600",
          bgColor: "bg-green-50 dark:bg-green-950/50",
          borderColor: "border-green-500",
          textColor: "text-green-900 dark:text-green-100",
          iconColor: "text-green-600 dark:text-green-400",
          accentColor: "bg-green-500",
          icon: CheckCircle2,
          title: "NORMAL OPERATION",
          message: "Sensor reading is within safe limits. Continue monitoring standard protocols.",
          badge: "SAFE",
          badgeColor: "bg-green-600",
        }
      case "medium":
        return {
          bgGradient: "from-yellow-500 to-orange-600",
          bgColor: "bg-yellow-50 dark:bg-yellow-950/50",
          borderColor: "border-yellow-500",
          textColor: "text-yellow-900 dark:text-yellow-100",
          iconColor: "text-yellow-600 dark:text-yellow-400",
          accentColor: "bg-yellow-500",
          icon: AlertTriangle,
          title: "MEDIUM RISK ALERT",
          message: "Sensor reading approaching threshold. Exercise caution and increase monitoring frequency.",
          badge: "CAUTION",
          badgeColor: "bg-yellow-600",
        }
      case "critical":
        return {
          bgGradient: "from-red-500 to-rose-700",
          bgColor: "bg-red-50 dark:bg-red-950/50",
          borderColor: "border-red-500",
          textColor: "text-red-900 dark:text-red-100",
          iconColor: "text-red-600 dark:text-red-400",
          accentColor: "bg-red-500",
          icon: AlertCircle,
          title: "CRITICAL ALERT",
          message: "Sensor reading exceeded threshold. IMMEDIATE ACTION REQUIRED.",
          badge: "EMERGENCY",
          badgeColor: "bg-red-600 animate-pulse",
        }
    }
  }

  const config = getSeverityConfig(severity)
  const Icon = config.icon

  return (
    <div
      className={`fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 transition-all duration-300 ${
        isVisible ? "opacity-100" : "opacity-0 pointer-events-none"
      }`}
      onClick={() => {
        setIsVisible(false)
        setTimeout(onClose, 300)
      }}
    >
      <div
        className={`bg-background border-4 ${config.borderColor} rounded-2xl w-[90%] md:w-[70%] h-[85vh] shadow-2xl overflow-hidden transition-all duration-300 flex flex-col ${
          isVisible ? "scale-100 opacity-100" : "scale-95 opacity-0"
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className={`bg-gradient-to-r ${config.bgGradient} p-8 text-white relative`}>
          <div className="absolute top-4 right-4 flex gap-3 items-center">
            <span className={`${config.badgeColor} px-4 py-2 rounded-full text-sm font-bold tracking-wider`}>
              {config.badge}
            </span>
            <button
              onClick={() => {
                setIsVisible(false)
                setTimeout(onClose, 300)
              }}
              className="p-2 hover:bg-white/20 rounded-full transition-colors"
            >
              <X size={28} />
            </button>
          </div>

          <div className="flex items-center gap-6">
            <div className="bg-white/20 p-6 rounded-2xl backdrop-blur-sm">
              <Icon size={64} className="drop-shadow-lg" />
            </div>
            <div className="flex-1">
              <h1 className="text-4xl md:text-5xl font-black tracking-tight mb-2">{config.title}</h1>
              <p className="text-xl opacity-90 mb-3">{benchName}</p>
              <div className="flex items-center gap-2 text-sm opacity-80">
                <Clock size={16} />
                <span>{new Date().toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-8 space-y-6">
          {/* Message */}
          <div className={`${config.bgColor} border-2 ${config.borderColor} rounded-xl p-6`}>
            <p className={`text-lg leading-relaxed ${config.textColor} font-medium`}>{config.message}</p>
          </div>

          {/* Large Reading Display */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className={`${config.bgColor} border-2 ${config.borderColor} rounded-xl p-6 space-y-4`}>
              <div className="flex items-center gap-3 mb-4">
                <Activity className={config.iconColor} size={24} />
                <h3 className={`text-xl font-bold ${config.textColor}`}>Sensor Reading</h3>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-current/20">
                  <span className={`text-sm ${config.textColor} opacity-70`}>Sensor Name:</span>
                  <span className={`font-bold text-lg ${config.textColor}`}>{reading.sensorName}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-current/20">
                  <span className={`text-sm ${config.textColor} opacity-70`}>Sensor ID:</span>
                  <span className={`font-mono text-sm ${config.textColor}`}>{reading.sensorId}</span>
                </div>
                <div className="flex justify-between items-center py-3">
                  <span className={`text-sm ${config.textColor} opacity-70`}>Current Value:</span>
                  <span className={`font-black text-3xl ${config.textColor}`}>
                    {reading.value} <span className="text-xl">{reading.unit}</span>
                  </span>
                </div>
              </div>
            </div>

            <div className={`${config.bgColor} border-2 ${config.borderColor} rounded-xl p-6 space-y-4`}>
              <div className="flex items-center gap-3 mb-4">
                <TrendingUp className={config.iconColor} size={24} />
                <h3 className={`text-xl font-bold ${config.textColor}`}>Threshold Analysis</h3>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-current/20">
                  <span className={`text-sm ${config.textColor} opacity-70`}>Safe Threshold:</span>
                  <span className={`font-bold text-lg ${config.textColor}`}>
                    {reading.threshold} {reading.unit}
                  </span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-current/20">
                  <span className={`text-sm ${config.textColor} opacity-70`}>Variance:</span>
                  <span className={`font-bold text-lg ${config.textColor}`}>
                    {((reading.value / reading.threshold) * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-current/20">
                  <span className={`text-sm ${config.textColor} opacity-70`}>Excess Amount:</span>
                  <span className={`font-bold text-lg ${config.textColor}`}>
                    +{(reading.value - reading.threshold).toFixed(1)} {reading.unit}
                  </span>
                </div>
                <div className="py-3">
                  <div className={`${config.textColor} opacity-70 text-xs mb-2`}>Status Level</div>
                  <div className="w-full bg-gray-200 dark:bg-gray-800 rounded-full h-4 overflow-hidden">
                    <div
                      className={`h-full ${config.accentColor} transition-all duration-500`}
                      style={{ width: `${Math.min((reading.value / reading.threshold) * 100, 100)}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Notifications Log */}
          <div className="bg-muted rounded-xl p-6">
            <h3 className="text-lg font-bold text-foreground mb-4">Notifications Dispatched</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-background rounded-lg p-4 border border-border">
                <p className="text-xs text-muted-foreground mb-2">SMS Alert</p>
                <p className="font-mono text-sm">+91{smsNumber}</p>
                <p className="text-xs text-green-600 mt-2">✓ Sent successfully</p>
              </div>
              <div className="bg-background rounded-lg p-4 border border-border">
                <p className="text-xs text-muted-foreground mb-2">Email Alert</p>
                <p className="font-mono text-sm text-ellipsis overflow-hidden">
                  alert{Math.floor(Math.random() * 99)}@{emailDomain}.in
                </p>
                <p className="text-xs text-green-600 mt-2">✓ Sent successfully</p>
              </div>
              <div className="bg-background rounded-lg p-4 border border-border">
                <p className="text-xs text-muted-foreground mb-2">Dashboard Log</p>
                <p className="text-sm">{new Date().toLocaleTimeString()}</p>
                <p className="text-xs text-green-600 mt-2">✓ Logged successfully</p>
              </div>
            </div>
          </div>
        </div>

        <div className={`bg-gradient-to-r ${config.bgGradient} p-6 text-white text-center`}>
          <p className="text-lg font-semibold">Press ENTER or ESC to acknowledge and dismiss</p>
        </div>
      </div>
    </div>
  )
}
