"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useMine } from "@/lib/context"
import { useTranslation } from "@/lib/use-translation"
import { useAlerts } from "@/hooks/use-alerts"
import { Menu, X, Bell } from "lucide-react"
import { useState, useEffect } from "react"
import Image from "next/image"

export function Navbar() {
  const pathname = usePathname()
  const { isDarkMode, toggleDarkMode } = useMine()
  const { t } = useTranslation()
  const { unreadCount } = useAlerts()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [hasNewAlert, setHasNewAlert] = useState(false)

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [isDarkMode])

  useEffect(() => {
    if (unreadCount > 0) {
      setHasNewAlert(true)
      const timer = setTimeout(() => setHasNewAlert(false), 3000)
      return () => clearTimeout(timer)
    }
  }, [unreadCount])

  const navItems = [
    { label: t("home.title"), href: "/" },
    { label: t("status.title"), href: "/status" },
    { label: t("aiModel.title"), href: "/ai-model" },
    { label: "ML Predictions", href: "/ml-predictions" },
    { label: t("notifications.title"), href: "/notifications" },
    { label: t("settings.title"), href: "/settings" },
  ]

  const isActive = (href: string) => pathname === href

  return (
    <nav className="bg-card border-b border-border sticky top-0 z-50 shadow-sm transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo/Brand */}
          <div className="flex flex-col items-center justify-center gap-0.5 py-1">
            <Image
              src="/logo.jpg"
              alt="ABHAY.AI Logo"
              width={80}
              height={32}
              className="h-8 w-auto object-contain"
              priority
            />
            <span className="text-xs font-bold tracking-wider bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              ABHAY.AI
            </span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 relative ${
                  isActive(item.href) ? "bg-accent text-accent-foreground" : "text-foreground hover:bg-secondary"
                }`}
              >
                {item.label}
                {item.href === "/notifications" && unreadCount > 0 && (
                  <span
                    className={`absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold ${hasNewAlert ? "animate-pulse" : ""}`}
                  >
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </span>
                )}
              </Link>
            ))}
          </div>

          {/* Right side controls */}
          <div className="flex items-center gap-2">
            <Link
              href="/notifications"
              className="relative p-2 rounded-md hover:bg-secondary transition-all duration-200 transform hover:scale-110"
              aria-label="Notifications"
            >
              <Bell size={20} className={hasNewAlert ? "animate-pulse text-red-500" : ""} />
              {unreadCount > 0 && (
                <span
                  className={`absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold ${hasNewAlert ? "animate-bounce" : ""}`}
                >
                  {unreadCount > 9 ? "9+" : unreadCount}
                </span>
              )}
            </Link>
            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-md hover:bg-secondary transition-all duration-200 transform hover:scale-110"
              aria-label="Toggle dark mode"
            >
              {isDarkMode ? "☀️" : "🌙"}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-md hover:bg-secondary transition-all duration-200"
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden pb-3 space-y-1 animate-fade-in">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`block px-3 py-2 rounded-md text-sm transition-all duration-200 relative ${
                  isActive(item.href) ? "bg-accent text-accent-foreground" : "text-foreground hover:bg-secondary"
                }`}
              >
                {item.label}
                {item.href === "/notifications" && unreadCount > 0 && (
                  <span className="ml-2 bg-red-500 text-white text-xs rounded-full px-2 py-0.5 font-bold">
                    {unreadCount}
                  </span>
                )}
              </Link>
            ))}
          </div>
        )}
      </div>
    </nav>
  )
}
