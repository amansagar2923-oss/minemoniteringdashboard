"use client"

import type React from "react"
import { createContext, useContext, useState, useCallback } from "react"

export interface Sensor {
  id: string
  name: string
  threshold: number
  unit: string
}

export interface BenchData {
  id: string
  name: string
  sensors: Sensor[]
}

export interface Alert {
  id: string
  benchId: string
  sensorId: string
  sensorName: string
  value: number
  threshold: number
  unit: string
  severity: "normal" | "medium" | "critical"
  timestamp: Date
  sms: string
  email: string
  read?: boolean
}

export interface SensorActivity {
  benchId: string
  sensorId: string
  sensorName: string
  value: number
  threshold: number
  unit: string
  timestamp: Date
}

export type Language = "en" | "hi" | "mr" | "gu" | "te" | "ta" | "kn" | "ml" | "or" | "bn"

export interface MineContextType {
  benches: BenchData[]
  sensors: Sensor[]
  alerts: Alert[]
  sensorActivity: SensorActivity[]
  language: Language
  isDarkMode: boolean
  mineImageUrl: string | null
  addBench: (bench: BenchData) => void
  addSensor: (sensor: Sensor) => void
  addAlert: (alert: Alert) => void
  updateThreshold: (sensorId: string, newThreshold: number) => void
  setLanguage: (lang: Language) => void
  toggleDarkMode: () => void
  getSensorValue: (sensorId: string, benchId: string) => number | null
  setMineImageUrl: (url: string) => void
  recordSensorActivity: (activity: SensorActivity) => void
  markAlertsAsRead: () => void
}

const MineContext = createContext<MineContextType | undefined>(undefined)

export function MineProvider({ children }: { children: React.ReactNode }) {
  const [benches, setBenches] = useState<BenchData[]>(
    Array.from({ length: 5 }, (_, i) => ({
      id: `bench-${i + 1}`,
      name: `Bench ${i + 1}`,
      sensors: [
        { id: `b${i + 1}-s1`, name: "Vibration", threshold: 50, unit: "mm/s" },
        { id: `b${i + 1}-s2`, name: "Humidity", threshold: 60, unit: "%" },
        { id: `b${i + 1}-s3`, name: "Temperature", threshold: 70, unit: "°C" },
        { id: `b${i + 1}-s4`, name: "Pore Pressure", threshold: 80, unit: "kPa" },
      ],
    })),
  )

  const [sensors, setSensors] = useState<Sensor[]>([])
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [sensorActivity, setSensorActivity] = useState<SensorActivity[]>([])
  const [language, setLanguageState] = useState<Language>("en")
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [mineImageUrl, setMineImageUrl] = useState<string | null>(null)

  const addBench = useCallback((bench: BenchData) => {
    setBenches((prev) => [...prev, bench])
  }, [])

  const addSensor = useCallback((sensor: Sensor) => {
    setSensors((prev) => [...prev, sensor])
    setBenches((prev) =>
      prev.map((bench) => ({
        ...bench,
        sensors: [...bench.sensors, { ...sensor, id: `${bench.id}-${sensor.id}` }],
      })),
    )
  }, [])

  const addAlert = useCallback((alert: Alert) => {
    setAlerts((prev) => [...prev, { ...alert, id: `alert-${Date.now()}`, read: false }])
  }, [])

  const updateThreshold = useCallback((sensorId: string, newThreshold: number) => {
    setBenches((prev) =>
      prev.map((bench) => ({
        ...bench,
        sensors: bench.sensors.map((s) => (s.id === sensorId ? { ...s, threshold: newThreshold } : s)),
      })),
    )
  }, [])

  const toggleDarkMode = useCallback(() => {
    setIsDarkMode((prev) => !prev)
  }, [])

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang)
  }, [])

  const getSensorValue = (sensorId: string, benchId: string): number | null => {
    const key = `sensor-${benchId}-${sensorId}`
    const value = localStorage.getItem(key)
    return value ? Number.parseFloat(value) : null
  }

  const recordSensorActivity = useCallback((activity: SensorActivity) => {
    setSensorActivity((prev) => [...prev, activity])
  }, [])

  const markAlertsAsRead = useCallback(() => {
    setAlerts((prev) => prev.map((alert) => ({ ...alert, read: true })))
  }, [])

  return (
    <MineContext.Provider
      value={{
        benches,
        sensors,
        alerts,
        sensorActivity,
        language,
        isDarkMode,
        mineImageUrl,
        addBench,
        addSensor,
        addAlert,
        updateThreshold,
        setLanguage,
        toggleDarkMode,
        getSensorValue,
        setMineImageUrl,
        recordSensorActivity,
        markAlertsAsRead,
      }}
    >
      {children}
    </MineContext.Provider>
  )
}

export function useMine() {
  const context = useContext(MineContext)
  if (!context) {
    throw new Error("useMine must be used within MineProvider")
  }
  return context
}
