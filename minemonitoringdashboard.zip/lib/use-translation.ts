import { useMine } from "./context"
import { getTranslation } from "./translations"

export function useTranslation() {
  const { language } = useMine()

  const t = (key: string): string => {
    return getTranslation(language, key)
  }

  return { t, language }
}
