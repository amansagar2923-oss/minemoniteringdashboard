"use client"

import { Navbar } from "@/components/navbar"
import { MineProvider } from "@/lib/context"
import { NotificationsView } from "@/app/pages/notifications"

export default function Page() {
  return (
    <MineProvider>
      <Navbar />
      <NotificationsView />
    </MineProvider>
  )
}
