"use client"

import { Navbar } from "@/components/navbar"
import { MineProvider } from "@/lib/context"
import { MineMapView } from "@/app/pages/mine-map"

export default function Page() {
  return (
    <MineProvider>
      <Navbar />
      <MineMapView />
    </MineProvider>
  )
}
