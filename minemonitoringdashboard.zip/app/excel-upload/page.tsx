import { ExcelUploadView } from "@/app/pages/excel-upload"

export default function ExcelUploadPage() {
  return <ExcelUploadView />
}
