"use client"

import { useState, useEffect } from "react"
import { BenchSelector } from "@/components/bench-selector"
import { SensorInput } from "@/components/sensor-input"
import { AlertModal } from "@/components/alert-modal"
import { StatusGraphs } from "@/components/status-graphs"
import { useMine } from "@/lib/context"
import { useTranslation } from "@/lib/use-translation"
import { useThresholds } from "@/hooks/use-thresholds"
import { useToast } from "@/hooks/use-toast" // Added toast hook for on-screen notifications

export interface SensorReading {
  sensorId: string
  sensorName: string
  value: number
  threshold: number
  unit: string
}

export interface AlertState {
  isOpen: boolean
  reading: SensorReading | null
  severity: "normal" | "medium" | "critical"
}

export interface Alert {
  id: string
  benchId: string
  sensorId: string
  sensorName: string
  value: number
  threshold: number
  unit: string
  severity: "normal" | "medium" | "critical"
  timestamp: Date
  sms: string
  email: string
}

export function StatusView() {
  const { benches, addAlert, recordSensorActivity } = useMine()
  const { t } = useTranslation()
  const { thresholds } = useThresholds()
  const { toast } = useToast() // Added toast hook for on-screen notifications
  const [selectedBench, setSelectedBench] = useState(benches[0])
  const [alertState, setAlertState] = useState<AlertState>({
    isOpen: false,
    reading: null,
    severity: "normal",
  })
  const [sensorValues, setSensorValues] = useState<{ [key: string]: number }>({})
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>("default")
  const [graphUpdateTrigger, setGraphUpdateTrigger] = useState(0) // Added state to trigger graph updates

  useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission().then((permission) => {
        setNotificationPermission(permission)
        console.log("[v0] Notification permission:", permission)
      })
    }
  }, [])

  const handleSensorSubmit = async (
    sensorId: string,
    sensorName: string,
    value: number,
    threshold: number,
    unit: string,
  ) => {
    const dbThreshold = thresholds.find((t) => t.sensor_id === sensorId)
    const actualThreshold = dbThreshold ? dbThreshold.threshold_value : threshold

    localStorage.setItem(`sensor-${selectedBench.id}-${sensorId}`, value.toString())

    let severity: "normal" | "medium" | "critical" = "normal"
    const halfThreshold = actualThreshold / 2

    if (value < halfThreshold) {
      severity = "normal"
    } else if (value >= halfThreshold && value < actualThreshold) {
      severity = "medium"
    } else {
      severity = "critical"
    }

    const smsNumber = Math.floor(100000 + Math.random() * 900000).toString()
    const emailDomains = ["mining.ops", "safety.alert", "control.center", "alert.system", "emergency.ops"]
    const emailDomain = emailDomains[Math.floor(Math.random() * emailDomains.length)]
    const alertEmail = `alert${Math.floor(Math.random() * 99)}@${emailDomain}.in`

    const alertData: Alert = {
      id: `alert-${Date.now()}`,
      benchId: selectedBench.id,
      sensorId,
      sensorName,
      value,
      threshold: actualThreshold,
      unit,
      severity,
      timestamp: new Date(),
      sms: `+91${smsNumber}`,
      email: alertEmail,
    }

    recordSensorActivity({
      benchId: selectedBench.id,
      sensorId,
      sensorName,
      value,
      threshold: actualThreshold,
      unit,
      timestamp: new Date(),
    })

    addAlert(alertData)

    const toastVariants = {
      normal: {
        variant: "default" as const,
        title: "✓ Normal Operation",
        description: `${sensorName}: ${value}${unit} (Threshold: ${actualThreshold}${unit})`,
        className: "border-green-500 bg-green-50 dark:bg-green-950",
      },
      medium: {
        variant: "default" as const,
        title: "⚠️ Medium Risk Alert",
        description: `${sensorName}: ${value}${unit} approaching threshold ${actualThreshold}${unit}`,
        className: "border-yellow-500 bg-yellow-50 dark:bg-yellow-950",
      },
      critical: {
        variant: "destructive" as const,
        title: "🚨 CRITICAL ALERT",
        description: `${sensorName}: ${value}${unit} exceeds threshold ${actualThreshold}${unit}`,
        className: "border-red-500 bg-red-50 dark:bg-red-950",
      },
    }

    const toastConfig = toastVariants[severity]
    toast({
      title: toastConfig.title,
      description: toastConfig.description,
      variant: toastConfig.variant,
      className: toastConfig.className,
    })

    try {
      const mlResponse = await fetch("/api/ml/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sensor_id: sensorId,
          sensor_name: sensorName,
          sensor_value: value,
        }),
      })

      if (mlResponse.ok) {
        const mlData = await mlResponse.json()
        console.log("[v0] ML Prediction:", mlData.prediction)
      }

      const message =
        severity === "critical"
          ? `🚨 CRITICAL: ${sensorName} reading ${value}${unit} exceeds threshold ${actualThreshold}${unit}`
          : severity === "medium"
            ? `⚠️ WARNING: ${sensorName} at ${value}${unit} approaching threshold ${actualThreshold}${unit}`
            : `✓ NORMAL: ${sensorName} at ${value}${unit} is within safe range (threshold: ${actualThreshold}${unit})`

      const response = await fetch("/api/alerts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sensor_name: sensorName,
          sensor_value: value,
          threshold: actualThreshold,
          severity: severity,
          message: message,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        console.log("[v0] Alert saved successfully:", data)

        if (severity === "critical" || severity === "medium") {
          fetch("/api/notifications/sms", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              phone: alertData.sms,
              message: message,
            }),
          }).catch((err) => console.error("[v0] SMS send error:", err))

          fetch("/api/notifications/email", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              subject: severity === "critical" ? "🚨 CRITICAL ALERT" : "⚠️ WARNING ALERT",
              message: message,
              sensor_name: sensorName,
              sensor_value: value,
              threshold: actualThreshold,
            }),
          }).catch((err) => console.error("[v0] Email send error:", err))
        }
      }
    } catch (error) {
      console.error("[v0] Error processing alert:", error)
    }

    if (severity === "critical") {
      setAlertState({
        isOpen: true,
        reading: { sensorId, sensorName, value, threshold: actualThreshold, unit },
        severity,
      })
    }

    setSensorValues((prev) => ({ ...prev, [`${selectedBench.id}-${sensorId}`]: value }))

    setGraphUpdateTrigger((prev) => prev + 1)
  }

  const closeAlert = () => {
    setAlertState({ isOpen: false, reading: null, severity: "normal" })
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">{t("status.title")}</h1>
          <p className="text-muted-foreground">{t("status.subtitle")}</p>
        </div>

        {/* Bench Selector */}
        <BenchSelector benches={benches} selectedBench={selectedBench} onSelectBench={setSelectedBench} />

        {/* Sensors Grid */}
        <div className="mt-8">
          <h2 className="text-xl font-semibold text-foreground mb-4">{t("status.activeSensors")}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {selectedBench.sensors.map((sensor) => (
              <SensorInput
                key={sensor.id}
                sensor={sensor}
                benchId={selectedBench.id}
                onSubmit={(value) => handleSensorSubmit(sensor.id, sensor.name, value, sensor.threshold, sensor.unit)}
              />
            ))}
          </div>
        </div>

        <div className="mt-12">
          <h2 className="text-xl font-semibold text-foreground mb-4">Active Risk Zones</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {benches.map((bench, index) => {
              const riskLevel = Math.floor(Math.random() * 100)
              let severity: "safe" | "medium" | "critical"
              if (riskLevel < 40) severity = "safe"
              else if (riskLevel < 75) severity = "medium"
              else severity = "critical"

              const severityColors = {
                safe: "bg-green-50 dark:bg-green-950 border-green-300 dark:border-green-700 text-green-900 dark:text-green-100",
                medium:
                  "bg-yellow-50 dark:bg-yellow-950 border-yellow-300 dark:border-yellow-700 text-yellow-900 dark:text-yellow-100",
                critical: "bg-red-50 dark:bg-red-950 border-red-300 dark:border-red-700 text-red-900 dark:text-red-100",
              }

              return (
                <div key={bench.id} className={`border-2 rounded-lg p-4 ${severityColors[severity]}`}>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold">{bench.name}</h3>
                    <div
                      className={`w-4 h-4 rounded-full ${
                        severity === "safe" ? "bg-green-500" : severity === "medium" ? "bg-yellow-500" : "bg-red-500"
                      }`}
                    />
                  </div>
                  <p className="text-sm mb-2">Risk Level: {riskLevel}%</p>
                  <p className="text-xs opacity-75">Status: {severity.toUpperCase()}</p>
                </div>
              )
            })}
          </div>
        </div>

        {/* Status Graphs */}
        <StatusGraphs benchId={selectedBench.id} sensorValues={sensorValues} updateTrigger={graphUpdateTrigger} />

        {/* Alert Modal */}
        {alertState.isOpen && alertState.reading && (
          <AlertModal
            reading={alertState.reading}
            severity={alertState.severity}
            benchName={selectedBench.name}
            onClose={closeAlert}
          />
        )}
      </div>
    </div>
  )
}
