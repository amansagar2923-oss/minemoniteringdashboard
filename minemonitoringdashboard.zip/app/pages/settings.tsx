"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useMine } from "@/lib/context"
import type { Language } from "@/lib/translations"
import { useTranslation } from "@/lib/use-translation"
import { Plus, Upload } from "lucide-react"

export function SettingsView() {
  const { language, setLanguage, isDarkMode, toggleDarkMode, setMineImageUrl, addSensor } = useMine()
  const { t } = useTranslation()
  const [newSensorName, setNewSensorName] = useState("")
  const [newSensorThreshold, setNewSensorThreshold] = useState("")
  const [error, setError] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const languages: { code: Language; name: string }[] = [
    { code: "en", name: "English" },
    { code: "hi", name: "हिन्दी (Hindi)" },
    { code: "mr", name: "मराठी (Marathi)" },
    { code: "gu", name: "ગુજરાતી (Gujarati)" },
    { code: "te", name: "తెలుగు (Telugu)" },
    { code: "ta", name: "தமிழ் (Tamil)" },
    { code: "kn", name: "ಕನ್ನಡ (Kannada)" },
    { code: "ml", name: "മലയാളം (Malayalam)" },
    { code: "or", name: "ଓଡ଼ିଆ (Odia)" },
    { code: "bn", name: "বাংলা (Bengali)" },
  ]

  const handleAddSensor = () => {
    if (!newSensorName.trim()) {
      setError("Sensor name is required")
      return
    }
    const threshold = Number.parseFloat(newSensorThreshold)
    if (isNaN(threshold) || threshold <= 0) {
      setError("Please enter a valid threshold value")
      return
    }

    addSensor({
      id: `custom-sensor-${Date.now()}`,
      name: newSensorName,
      threshold,
    })

    setNewSensorName("")
    setNewSensorThreshold("")
    setError("")
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        const dataUrl = event.target?.result as string
        setMineImageUrl(dataUrl)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">{t("settings.title")}</h1>
        <p className="text-muted-foreground mb-8">Customize your mining monitoring system</p>

        <div className="space-y-8">
          {/* Language Settings */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">{t("settings.language")}</h2>
            <p className="text-sm text-muted-foreground mb-4">
              Select your preferred language. The interface will update immediately.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => setLanguage(lang.code)}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    language === lang.code
                      ? "bg-accent text-accent-foreground"
                      : "bg-secondary text-foreground hover:bg-muted"
                  }`}
                >
                  {lang.name}
                </button>
              ))}
            </div>
          </div>

          {/* Theme Settings */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">{t("settings.theme")}</h2>
            <p className="text-sm text-muted-foreground mb-4">
              Toggle between light and dark mode for comfortable viewing.
            </p>
            <button
              onClick={toggleDarkMode}
              className={`px-6 py-2 rounded-lg font-medium transition-colors ${
                isDarkMode ? "bg-accent text-accent-foreground" : "bg-secondary text-foreground"
              }`}
            >
              {isDarkMode ? "🌙 Dark Mode" : "☀️ Light Mode"}
            </button>
          </div>

          {/* Add New Sensor */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">{t("settings.sensors")}</h2>
            <p className="text-sm text-muted-foreground mb-4">
              Create a custom sensor that will automatically appear in all benches.
            </p>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-foreground block mb-1">Sensor Name</label>
                <input
                  type="text"
                  value={newSensorName}
                  onChange={(e) => {
                    setNewSensorName(e.target.value)
                    setError("")
                  }}
                  placeholder="e.g., Pressure Monitor"
                  className="w-full px-3 py-2 bg-input border border-border rounded-lg text-foreground placeholder-muted-foreground text-sm focus:outline-none focus:ring-1 focus:ring-accent"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground block mb-1">Threshold Value</label>
                <input
                  type="number"
                  value={newSensorThreshold}
                  onChange={(e) => {
                    setNewSensorThreshold(e.target.value)
                    setError("")
                  }}
                  placeholder="e.g., 100"
                  className="w-full px-3 py-2 bg-input border border-border rounded-lg text-foreground placeholder-muted-foreground text-sm focus:outline-none focus:ring-1 focus:ring-accent"
                />
              </div>
              {error && <p className="text-sm text-red-600">{error}</p>}
              <button
                onClick={handleAddSensor}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-accent text-accent-foreground rounded-lg hover:opacity-90 transition-opacity font-medium"
              >
                <Plus size={18} />
                Add Sensor
              </button>
            </div>
          </div>

          {/* 3D Mine Model Upload */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">{t("settings.mineImage")}</h2>
            <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-2 px-6 py-3 bg-accent text-accent-foreground rounded-lg hover:opacity-90 transition-opacity font-medium"
              >
                <Upload size={18} />
                Upload Image
              </button>
              <p className="text-xs text-muted-foreground mt-3">Supported formats: JPG, PNG, GIF (Max 5MB)</p>
            </div>
          </div>

          {/* System Info */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">System Information</h2>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">System Version</span>
                <span className="text-foreground font-medium">3.2.1</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">API Version</span>
                <span className="text-foreground font-medium">v2.0</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Database Status</span>
                <span className="text-green-600 font-medium">Connected</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Last Backup</span>
                <span className="text-foreground font-medium">Today at 03:30 AM</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
