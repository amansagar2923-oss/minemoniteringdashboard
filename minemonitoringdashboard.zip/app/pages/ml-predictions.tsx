"use client"

import { useState, useEffect } from "react"
import { Brain, TrendingUp, Activity, Clock, Download, BarChart3, LineChartIcon, PieChartIcon } from "lucide-react"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from "recharts"
import { Button } from "@/components/ui/button"

interface Prediction {
  id: number
  sensor_id: string
  sensor_name: string
  input_value: number
  predicted_risk: "normal" | "medium" | "critical"
  confidence: number
  recommendation: string
  created_at: string
}

export function MLPredictionsView() {
  const [predictions, setPredictions] = useState<Prediction[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchPredictions()
    const interval = setInterval(fetchPredictions, 10000)
    return () => clearInterval(interval)
  }, [])

  const fetchPredictions = async () => {
    try {
      const response = await fetch("/api/ml/predict?limit=50")
      const data = await response.json()

      if (data.success) {
        setPredictions(data.predictions)
      }
    } catch (error) {
      console.error("Error fetching predictions:", error)
    } finally {
      setLoading(false)
    }
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "normal":
        return "#10b981"
      case "medium":
        return "#f59e0b"
      case "critical":
        return "#ef4444"
      default:
        return "#6b7280"
    }
  }

  const getRiskBgColor = (risk: string) => {
    switch (risk) {
      case "normal":
        return "text-green-600 bg-green-500/10 border-green-500/30"
      case "medium":
        return "text-yellow-600 bg-yellow-500/10 border-yellow-500/30"
      case "critical":
        return "text-red-600 bg-red-500/10 border-red-500/30"
      default:
        return "text-gray-600 bg-gray-500/10 border-gray-500/30"
    }
  }

  const stats = {
    total: predictions.length,
    normal: predictions.filter((p) => p.predicted_risk === "normal").length,
    medium: predictions.filter((p) => p.predicted_risk === "medium").length,
    critical: predictions.filter((p) => p.predicted_risk === "critical").length,
    avgConfidence:
      predictions.length > 0
        ? (predictions.reduce((sum, p) => sum + p.confidence, 0) / predictions.length).toFixed(1)
        : "0",
  }

  const sensorDataMap = predictions.reduce(
    (acc, pred) => {
      if (!acc[pred.sensor_name]) {
        acc[pred.sensor_name] = []
      }
      acc[pred.sensor_name].push(pred)
      return acc
    },
    {} as Record<string, Prediction[]>,
  )

  const timeSeriesData = predictions
    .slice(0, 20)
    .reverse()
    .map((pred, idx) => ({
      time: new Date(pred.created_at).toLocaleTimeString(),
      value: pred.input_value,
      confidence: pred.confidence,
      risk: pred.predicted_risk,
      sensor: pred.sensor_name,
    }))

  const riskDistribution = [
    { name: "Normal", value: stats.normal, color: "#10b981" },
    { name: "Medium", value: stats.medium, color: "#f59e0b" },
    { name: "Critical", value: stats.critical, color: "#ef4444" },
  ]

  const sensorComparison = Object.entries(sensorDataMap)
    .map(([sensor, data]) => ({
      sensor: sensor.substring(0, 15),
      avgValue: (data.reduce((sum, p) => sum + p.input_value, 0) / data.length).toFixed(2),
      avgConfidence: (data.reduce((sum, p) => sum + p.confidence, 0) / data.length).toFixed(1),
      count: data.length,
    }))
    .slice(0, 10)

  const downloadReport = async () => {
    // Create a comprehensive report with all data
    const reportData = {
      generatedAt: new Date().toLocaleString(),
      statistics: stats,
      predictions: predictions.map((pred) => ({
        ...pred,
        suggestions: getSuggestion(pred.predicted_risk),
        precautions: getPrecautions(pred.predicted_risk),
        immediateAction: getImmediateAction(pred.predicted_risk),
      })),
      riskDistribution,
      sensorComparison,
      timeSeriesData,
    }

    // Generate comprehensive CSV report
    const reportLines = [
      "=== ABHAY.AI MINING MONITORING SYSTEM ===",
      `Report Generated: ${reportData.generatedAt}`,
      "",
      "=== EXECUTIVE SUMMARY ===",
      `Total Predictions: ${stats.total}`,
      `Normal Readings: ${stats.normal}`,
      `Medium Risk: ${stats.medium}`,
      `Critical Alerts: ${stats.critical}`,
      `Average Confidence: ${stats.avgConfidence}%`,
      `Model Version: v3.2.1`,
      "",
      "=== RISK DISTRIBUTION ===",
      ...riskDistribution.map(
        (item) => `${item.name}: ${item.value} (${((item.value / stats.total) * 100).toFixed(1)}%)`,
      ),
      "",
      "=== SENSOR COMPARISON ANALYTICS ===",
      "Sensor,Average Value,Average Confidence,Reading Count",
      ...sensorComparison.map((item) => `${item.sensor},${item.avgValue},${item.avgConfidence}%,${item.count}`),
      "",
      "=== TIME SERIES DATA (Last 20 Readings) ===",
      "Time,Sensor,Value,Confidence,Risk Level",
      ...timeSeriesData.map((item) => `${item.time},${item.sensor},${item.value},${item.confidence}%,${item.risk}`),
      "",
      "=== DETAILED PREDICTIONS WITH RECOMMENDATIONS ===",
      "ID,Sensor ID,Sensor Name,Value,Risk,Confidence,Suggestion,Precautions,Immediate Action,Timestamp",
      ...reportData.predictions.map((pred) =>
        [
          pred.id,
          pred.sensor_id,
          pred.sensor_name,
          pred.input_value,
          pred.predicted_risk.toUpperCase(),
          `${pred.confidence}%`,
          `"${pred.suggestions}"`,
          `"${pred.precautions}"`,
          `"${pred.immediateAction}"`,
          new Date(pred.created_at).toLocaleString(),
        ].join(","),
      ),
      "",
      "=== SAFETY RECOMMENDATIONS ===",
      ...generateSafetyRecommendations(stats),
      "",
      "=== REPORT END ===",
      `Generated by ABHAY.AI Mining Monitoring System`,
    ]

    const csvContent = reportLines.join("\n")
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", `ABHAY_AI_Complete_Report_${new Date().toISOString().split("T")[0]}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  // Helper functions for enhanced reporting
  const getSuggestion = (risk: string): string => {
    switch (risk) {
      case "normal":
        return "Continue regular monitoring schedule. All parameters within safe operational limits."
      case "medium":
        return "Increase monitoring frequency. Review operational procedures and prepare contingency measures."
      case "critical":
        return "Implement emergency protocols immediately. Evacuate affected areas and notify all personnel."
      default:
        return "Review sensor calibration and verify readings."
    }
  }

  const getPrecautions = (risk: string): string => {
    switch (risk) {
      case "normal":
        return "Maintain routine safety checks. Ensure all equipment is properly calibrated."
      case "medium":
        return "Alert supervisors. Restrict access to affected zones. Prepare emergency equipment for deployment."
      case "critical":
        return "IMMEDIATE: Stop all operations in affected area. Activate emergency response team. Ensure all personnel accounted for."
      default:
        return "Follow standard operating procedures."
    }
  }

  const getImmediateAction = (risk: string): string => {
    switch (risk) {
      case "normal":
        return "No immediate action required. Continue normal operations."
      case "medium":
        return "1. Notify shift supervisor 2. Increase sensor monitoring 3. Prepare evacuation routes 4. Brief response team"
      case "critical":
        return "1. EVACUATE IMMEDIATELY 2. Sound alarm 3. Call emergency services 4. Activate rescue protocols 5. Secure area"
      default:
        return "Verify sensor status and consult safety manual."
    }
  }

  const generateSafetyRecommendations = (statistics: typeof stats): string[] => {
    const recommendations = []

    if (statistics.critical > 0) {
      recommendations.push(
        "⚠️ URGENT: Critical alerts detected. Immediate review of affected areas required.",
        `- ${statistics.critical} critical condition(s) require immediate attention`,
        "- Implement emergency response protocols",
        "- Conduct thorough safety inspection before resuming operations",
      )
    }

    if (statistics.medium > 5) {
      recommendations.push(
        `⚠️ WARNING: ${statistics.medium} medium-risk conditions detected.`,
        "- Schedule comprehensive equipment inspection",
        "- Review and update safety procedures",
        "- Increase monitoring frequency in affected zones",
      )
    }

    if (statistics.normal > statistics.total * 0.8) {
      recommendations.push(
        "✓ POSITIVE: Majority of readings within safe parameters.",
        "- Continue current operational practices",
        "- Maintain regular maintenance schedule",
      )
    }

    const avgConf = Number.parseFloat(statistics.avgConfidence)
    if (avgConf < 70) {
      recommendations.push(
        "⚠️ MODEL CONFIDENCE: Below optimal threshold.",
        "- Consider sensor recalibration",
        "- Verify data quality and sensor placement",
        "- Update ML model training data",
      )
    }

    return recommendations
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2 flex items-center gap-3">
              <Brain className="text-accent" size={32} />
              ML Predictions Dashboard
            </h1>
            <p className="text-muted-foreground">Real-time AI risk predictions and analytics</p>
          </div>
          <Button onClick={downloadReport} className="flex items-center gap-2" disabled={predictions.length === 0}>
            <Download size={18} />
            Download Report
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-card border border-border rounded-lg p-4">
            <p className="text-muted-foreground text-sm">Total Predictions</p>
            <p className="text-2xl font-bold text-foreground mt-2">{stats.total}</p>
          </div>
          <div className="bg-card border border-green-500/30 rounded-lg p-4">
            <p className="text-muted-foreground text-sm">Normal</p>
            <p className="text-2xl font-bold text-green-600 mt-2">{stats.normal}</p>
          </div>
          <div className="bg-card border border-yellow-500/30 rounded-lg p-4">
            <p className="text-muted-foreground text-sm">Medium Risk</p>
            <p className="text-2xl font-bold text-yellow-600 mt-2">{stats.medium}</p>
          </div>
          <div className="bg-card border border-red-500/30 rounded-lg p-4">
            <p className="text-muted-foreground text-sm">Critical</p>
            <p className="text-2xl font-bold text-red-600 mt-2">{stats.critical}</p>
          </div>
        </div>

        {!loading && predictions.length > 0 && (
          <div className="space-y-6 mb-8">
            {/* Risk Distribution Pie Chart */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                <PieChartIcon size={20} />
                Risk Distribution
              </h2>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={riskDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {riskDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Time Series Line Chart */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                <LineChartIcon size={20} />
                Sensor Values Over Time (Last 20 Readings)
              </h2>
              <ResponsiveContainer width="100%" height={350}>
                <AreaChart data={timeSeriesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke="#8b5cf6"
                    fill="#8b5cf6"
                    fillOpacity={0.3}
                    name="Sensor Value"
                  />
                  <Area
                    type="monotone"
                    dataKey="confidence"
                    stroke="#06b6d4"
                    fill="#06b6d4"
                    fillOpacity={0.3}
                    name="Confidence %"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Sensor Comparison Bar Chart */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                <BarChart3 size={20} />
                Average Sensor Values by Sensor Type
              </h2>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={sensorComparison}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="sensor" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="avgValue" fill="#3b82f6" name="Avg Value" />
                  <Bar dataKey="avgConfidence" fill="#10b981" name="Avg Confidence %" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Confidence Line Chart */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                <TrendingUp size={20} />
                Prediction Confidence Trends
              </h2>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={timeSeriesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="confidence" stroke="#f59e0b" strokeWidth={2} name="Confidence %" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Model Info */}
        <div className="bg-accent/10 border border-accent/30 rounded-lg p-6 mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Activity size={20} className="text-accent" />
            <h3 className="text-lg font-semibold text-foreground">Model Performance</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Average Confidence</p>
              <p className="text-2xl font-bold text-accent mt-1">{stats.avgConfidence}%</p>
            </div>
            <div>
              <p className="text-muted-foreground">Model Version</p>
              <p className="text-lg font-semibold text-foreground mt-1">v3.2.1</p>
            </div>
            <div>
              <p className="text-muted-foreground">Total Predictions</p>
              <p className="text-lg font-semibold text-foreground mt-1">{stats.total}</p>
            </div>
          </div>
        </div>

        {/* Predictions List */}
        <div className="bg-card border border-border rounded-lg p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
            <TrendingUp size={20} />
            Recent Predictions
          </h2>

          {loading ? (
            <p className="text-muted-foreground text-center py-8">Loading predictions...</p>
          ) : predictions.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No predictions yet</p>
          ) : (
            <div className="space-y-3">
              {predictions.slice(0, 10).map((pred) => (
                <div key={pred.id} className={`border rounded-lg p-4 ${getRiskBgColor(pred.predicted_risk)}`}>
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="font-semibold text-foreground">{pred.sensor_name}</p>
                      <p className="text-xs text-muted-foreground font-mono mt-0.5">{pred.sensor_id}</p>
                    </div>
                    <div className="text-right">
                      <p
                        className={`font-bold text-lg uppercase ${
                          pred.predicted_risk === "normal"
                            ? "text-green-600"
                            : pred.predicted_risk === "medium"
                              ? "text-yellow-600"
                              : "text-red-600"
                        }`}
                      >
                        {pred.predicted_risk}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">{pred.confidence}% confidence</p>
                    </div>
                  </div>

                  <div className="bg-background/50 rounded p-3 mb-3">
                    <p className="text-sm text-foreground">
                      <span className="font-semibold">Reading:</span> {pred.input_value}{" "}
                      <span className="text-muted-foreground">(value unit)</span>
                    </p>
                  </div>

                  <div className="bg-background/50 rounded p-3">
                    <p className="text-xs text-muted-foreground font-semibold mb-1">RECOMMENDATION:</p>
                    <p className="text-sm text-foreground">{pred.recommendation}</p>
                  </div>

                  <div className="flex items-center gap-1 text-xs text-muted-foreground mt-3">
                    <Clock size={12} />
                    {new Date(pred.created_at).toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
