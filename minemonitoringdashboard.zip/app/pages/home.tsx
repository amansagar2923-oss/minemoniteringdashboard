"use client"

import { useEffect, useState } from "react"
import { Cloud, Radio, BarChart3, Activity } from "lucide-react"
import { useTranslation } from "@/lib/use-translation"
import { useMine } from "@/lib/context"
import { useAlerts } from "@/hooks/use-alerts"

interface WeatherData {
  temp: number
  condition: string
  humidity: number
}

export function Home() {
  const { t } = useTranslation()
  const { sensorActivity } = useMine()
  const { alerts: dbAlerts } = useAlerts()
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulated weather API call - in production, use real weather API
    const fetchWeather = async () => {
      try {
        // Using Open-Meteo free weather API for Singrauli, India (coordinates: 23.8659, 81.9637)
        const response = await fetch(
          "https://api.open-meteo.com/v1/forecast?latitude=23.8659&longitude=81.9637&current=temperature_2m,weather_code,relative_humidity_2m&temperature_unit=celsius",
        )
        const data = await response.json()
        const current = data.current
        setWeather({
          temp: Math.round(current.temperature_2m),
          condition: getWeatherCondition(current.weather_code),
          humidity: current.relative_humidity_2m,
        })
      } catch (error) {
        console.error("Weather fetch error:", error)
        setWeather({
          temp: 28,
          condition: "Partly Cloudy",
          humidity: 65,
        })
      } finally {
        setLoading(false)
      }
    }

    fetchWeather()
  }, [])

  const getWeatherCondition = (code: number): string => {
    const conditions: { [key: number]: string } = {
      0: "Clear",
      1: "Partly Cloudy",
      2: "Cloudy",
      3: "Overcast",
      45: "Foggy",
      48: "Foggy",
      51: "Light Rain",
      53: "Moderate Rain",
      55: "Heavy Rain",
      61: "Rain",
      63: "Rain",
      65: "Heavy Rain",
      71: "Snow",
      73: "Snow",
      75: "Heavy Snow",
      77: "Snow",
      80: "Rain Showers",
      81: "Heavy Rain Showers",
      82: "Violent Rain",
      85: "Snow Showers",
      86: "Heavy Snow Showers",
      95: "Thunderstorm",
      96: "Thunderstorm with Hail",
      99: "Thunderstorm with Hail",
    }
    return conditions[code] || "Unknown"
  }

  const recentActivities = sensorActivity.slice(-10).reverse()
  const totalSensors = 20
  const activeSensors = new Set(sensorActivity.map((a) => `${a.benchId}-${a.sensorId}`)).size

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
      {/* Hero Section without Mine Background */}
      <div className="relative py-16 overflow-hidden">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center py-12 px-8">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-3">{t("home.title")}</h1>
            <p className="text-muted-foreground text-lg">{t("home.subtitle")}</p>
          </div>
        </div>
      </div>

      {/* Info Cards Section */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Model Accuracy Card */}
          <div className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-muted-foreground text-sm font-medium">{t("home.modelAccuracy")}</p>
                <p className="text-3xl font-bold text-foreground mt-2">94.8%</p>
              </div>
              <div className="p-3 bg-accent/10 rounded-lg">
                <BarChart3 className="text-accent" size={24} />
              </div>
            </div>
            <p className="text-muted-foreground text-sm">Based on 10,000+ historical mining events</p>
          </div>

          {/* Weather Forecast Card */}
          <div className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-muted-foreground text-sm font-medium">{t("home.weather")}</p>
                <div className="mt-2">
                  {loading ? (
                    <p className="text-muted-foreground text-sm">Loading...</p>
                  ) : weather ? (
                    <div>
                      <p className="text-2xl font-bold text-foreground">{weather.temp}°C</p>
                      <p className="text-muted-foreground text-sm">{weather.condition}</p>
                    </div>
                  ) : null}
                </div>
              </div>
              <div className="p-3 bg-accent/10 rounded-lg">
                <Cloud className="text-accent" size={24} />
              </div>
            </div>
            <p className="text-muted-foreground text-sm">Singrauli, India • Humidity {weather?.humidity}%</p>
          </div>

          {/* Sensors Activeness Card */}
          <div className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-muted-foreground text-sm font-medium">{t("home.sensorsActive")}</p>
                <p className="text-3xl font-bold text-foreground mt-2">
                  {activeSensors}/{totalSensors}
                </p>
              </div>
              <div className="p-3 bg-accent/10 rounded-lg">
                <Radio className="text-accent" size={24} />
              </div>
            </div>
            <p className="text-muted-foreground text-sm">{totalSensors - activeSensors} sensors require activation</p>
          </div>
        </div>

        {recentActivities.length > 0 && (
          <div className="mt-12">
            <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
              <Activity className="text-accent" size={24} />
              Recent Sensor Activity
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {recentActivities.map((activity, index) => {
                const halfThreshold = activity.threshold / 2
                let severity: "normal" | "medium" | "critical" = "normal"
                let severityColor = "border-green-500 bg-green-50 dark:bg-green-950"
                let statusDot = "bg-green-500"

                if (activity.value < halfThreshold) {
                  severity = "normal"
                  severityColor = "border-green-500 bg-green-50 dark:bg-green-950"
                  statusDot = "bg-green-500"
                } else if (activity.value >= halfThreshold && activity.value < activity.threshold) {
                  severity = "medium"
                  severityColor = "border-yellow-500 bg-yellow-50 dark:bg-yellow-950"
                  statusDot = "bg-yellow-500"
                } else {
                  severity = "critical"
                  severityColor = "border-red-500 bg-red-50 dark:bg-red-950"
                  statusDot = "bg-red-500"
                }

                return (
                  <div
                    key={`${activity.benchId}-${activity.sensorId}-${index}`}
                    className={`border-2 rounded-lg p-4 ${severityColor}`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-foreground">{activity.sensorName}</h3>
                      <div className={`w-3 h-3 rounded-full ${statusDot} animate-pulse`} />
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-foreground">
                        Value:{" "}
                        <span className="font-bold">
                          {activity.value} {activity.unit}
                        </span>
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Threshold: {activity.threshold} {activity.unit}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Status: <span className="font-semibold uppercase">{severity}</span>
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(activity.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Quick Stats */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-card border border-border rounded-lg p-4 text-center">
            <p className="text-2xl font-bold text-accent">5</p>
            <p className="text-muted-foreground text-sm mt-1">Total Benches</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-4 text-center">
            <p className="text-2xl font-bold text-foreground">{dbAlerts.length}</p>
            <p className="text-muted-foreground text-sm mt-1">Active Alerts</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-4 text-center">
            <p className="text-2xl font-bold text-foreground">99.2%</p>
            <p className="text-muted-foreground text-sm mt-1">System Uptime</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-4 text-center">
            <p className="text-2xl font-bold text-foreground">Last 24h</p>
            <p className="text-muted-foreground text-sm mt-1">Data Coverage</p>
          </div>
        </div>
      </div>
    </div>
  )
}
