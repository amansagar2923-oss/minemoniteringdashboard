"use client"

import { useState, useEffect } from "react"
import { useMine } from "@/lib/context"
import { Download, ChevronDown, ChevronUp, Clock, Activity, TrendingUp, AlertCircle, Brain, Zap } from "lucide-react"
import { useAlerts } from "@/hooks/use-alerts"

interface MLPrediction {
  id: string
  sensor_id: string
  sensor_name: string
  input_value: number
  predicted_risk: "normal" | "medium" | "critical"
  confidence: number
  recommendation: string
  created_at: string
}

export function AIModelView() {
  const { benches, updateThreshold, alerts: contextAlerts, sensorActivity } = useMine()
  const { alerts: dbAlerts, loading: alertsLoading } = useAlerts()
  const [expandedSensor, setExpandedSensor] = useState<string | null>(null)
  const [editingThreshold, setEditingThreshold] = useState<string | null>(null)
  const [newThresholdValue, setNewThresholdValue] = useState("")
  const [last5MinActivity, setLast5MinActivity] = useState<typeof contextAlerts>([])
  const [mlPredictions, setMlPredictions] = useState<MLPrediction[]>([])
  const [last5MinPredictions, setLast5MinPredictions] = useState<MLPrediction[]>([])
  const [reportMode, setReportMode] = useState<"aiReport" | "threshold">("aiReport")
  const [recentSensorInputs, setRecentSensorInputs] = useState<typeof sensorActivity>([])
  const [totalAlerts, setTotalAlerts] = useState(0)
  const [modelAccuracy, setModelAccuracy] = useState<string>("0.0")

  useEffect(() => {
    const fetchPredictions = async () => {
      try {
        const response = await fetch("/api/ml/predict?limit=50")
        const data = await response.json()
        if (data.success) {
          setMlPredictions(data.predictions)

          // Filter last 5 minutes
          const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000)
          const recent = data.predictions.filter((pred: MLPrediction) => new Date(pred.created_at) > fiveMinutesAgo)
          setLast5MinPredictions(recent)

          if (data.predictions.length > 0) {
            const avgConfidence =
              data.predictions.reduce((sum: number, pred: MLPrediction) => sum + pred.confidence, 0) /
              data.predictions.length
            setModelAccuracy(avgConfidence.toFixed(1))
          }
        }
      } catch (error) {
        console.error("[v0] Error fetching predictions:", error)
      }
    }

    fetchPredictions()

    // Poll every 10 seconds for new predictions
    const interval = setInterval(fetchPredictions, 10000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (!alertsLoading) {
      setTotalAlerts(dbAlerts.length)
    }
  }, [dbAlerts, alertsLoading])

  useEffect(() => {
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000)
    const recent = contextAlerts.filter((alert) => new Date(alert.timestamp) > fiveMinutesAgo)
    setLast5MinActivity(recent)

    const recentInputs = sensorActivity.slice(-10).reverse()
    setRecentSensorInputs(recentInputs)
  }, [contextAlerts, sensorActivity])

  const handleThresholdUpdate = (sensorId: string, newThreshold: number) => {
    if (newThreshold > 0) {
      updateThreshold(sensorId, newThreshold)
      setEditingThreshold(null)
      setNewThresholdValue("")
    }
  }

  const handleDownloadAIReport = () => {
    const conditionCounts = {
      normal: last5MinActivity.filter((a) => a.severity === "normal").length,
      medium: last5MinActivity.filter((a) => a.severity === "medium").length,
      critical: last5MinActivity.filter((a) => a.severity === "critical").length,
    }

    const predictionCounts = {
      normal: last5MinPredictions.filter((p) => p.predicted_risk === "normal").length,
      medium: last5MinPredictions.filter((p) => p.predicted_risk === "medium").length,
      critical: last5MinPredictions.filter((p) => p.predicted_risk === "critical").length,
    }

    const avgConfidence =
      last5MinPredictions.length > 0
        ? (last5MinPredictions.reduce((sum, p) => sum + p.confidence, 0) / last5MinPredictions.length).toFixed(1)
        : "N/A"

    const reportData = {
      timestamp: new Date().toISOString(),
      modelAccuracy: "94.8%",
      reportPeriod: "Last 5 Minutes",
      totalAlerts: totalAlerts,
      totalPredictions: mlPredictions.length,
      avgConfidence,
      lastActivities: last5MinActivity.map((a) => ({
        bench: a.benchId,
        sensor: a.sensorName,
        value: a.value,
        threshold: a.threshold,
        severity: a.severity,
        time: new Date(a.timestamp).toLocaleTimeString(),
      })),
      lastPredictions: last5MinPredictions.map((p) => ({
        sensor: p.sensor_name,
        value: p.input_value,
        risk: p.predicted_risk,
        confidence: p.confidence,
        recommendation: p.recommendation,
        time: new Date(p.created_at).toLocaleTimeString(),
      })),
      sensorLogs: benches.flatMap((bench) =>
        bench.sensors.map((sensor) => ({
          bench: bench.name,
          sensor: sensor.name,
          threshold: sensor.threshold,
        })),
      ),
      conditions: conditionCounts,
      predictions: predictionCounts,
    }

    const reportText = `
╔════════════════════════════════════════════════════════════════════╗
║        AI ROCKFALL PREDICTION SYSTEM - OPERATIONAL REPORT          ║
║                    POWERED BY AI MODEL v3.2.1                      ║
╚════════════════════════════════════════════════════════════════════╝

REPORT GENERATION
Generated: ${new Date().toLocaleString()}
Report Period: ${reportData.reportPeriod}
Report ID: ${Date.now()}

════════════════════════════════════════════════════════════════════

MODEL PERFORMANCE METRICS
- AI Model Accuracy Rate: ${reportData.modelAccuracy}
- Average Confidence (5-min): ${reportData.avgConfidence}%
- Prediction Horizon: 72 hours ahead
- Total Alerts Generated: ${reportData.totalAlerts}
- Total ML Predictions: ${reportData.totalPredictions}
- System Uptime: 99.2%
- Avg Response Time: 2.3 seconds

════════════════════════════════════════════════════════════════════

ML PREDICTIONS (Last 5 Minutes)
${
  reportData.lastPredictions.length > 0
    ? reportData.lastPredictions
        .map(
          (p, i) => `
${i + 1}. TIMESTAMP: ${p.time}
   Sensor: ${p.sensor}
   Input Value: ${p.value}
   Predicted Risk: ${p.risk.toUpperCase()}
   Confidence: ${p.confidence}%
   ${p.risk === "critical" ? "🔴 CRITICAL RISK DETECTED" : p.risk === "medium" ? "🟡 MEDIUM RISK DETECTED" : "🟢 NORMAL OPERATION"}
   Recommendation: ${p.recommendation}`,
        )
        .join("\n")
    : "No ML predictions in the last 5 minutes"
}

════════════════════════════════════════════════════════════════════

ALERT EVENTS (Last 5 Minutes)
${
  reportData.lastActivities.length > 0
    ? reportData.lastActivities
        .map(
          (a, i) => `
${i + 1}. TIMESTAMP: ${a.time}
   Location: ${a.bench}
   Sensor: ${a.sensor}
   Reading: ${a.value} / Threshold: ${a.threshold}
   Status: ${a.severity.toUpperCase()}
   ${a.severity === "critical" ? "⚠️  CRITICAL - IMMEDIATE ACTION REQUIRED" : a.severity === "medium" ? "⚠️  MEDIUM RISK - MONITOR CLOSELY" : "✓ NORMAL - WITHIN SAFE PARAMETERS"}`,
        )
        .join("\n")
    : "No alert events in the last 5 minutes"
}

════════════════════════════════════════════════════════════════════

SENSOR CONFIGURATION LOG
${reportData.sensorLogs
  .map(
    (log, i) => `${i + 1}. ${log.bench} > ${log.sensor}
   Current Threshold: ${log.threshold}`,
  )
  .join("\n\n")}

════════════════════════════════════════════════════════════════════

PREDICTION SUMMARY (Last 5 Minutes)
🟢 Normal Predictions: ${reportData.predictions.normal}
🟡 Medium Risk Predictions: ${reportData.predictions.medium}
🔴 Critical Risk Predictions: ${reportData.predictions.critical}

TOTAL PREDICTIONS: ${reportData.predictions.normal + reportData.predictions.medium + reportData.predictions.critical}

════════════════════════════════════════════════════════════════════

CONDITIONS SUMMARY (Last 5 Minutes)
✓ Normal Operations: ${reportData.conditions.normal} events
⚠️  Medium Risk Alerts: ${reportData.conditions.medium} events
🔴 Critical Alerts: ${reportData.conditions.critical} events

TOTAL EVENTS: ${reportData.conditions.normal + reportData.conditions.medium + reportData.conditions.critical}

════════════════════════════════════════════════════════════════════

AI RECOMMENDATIONS:
${reportData.predictions.critical > 0 ? "- URGENT: Critical risk detected by AI model. Implement emergency protocols." : ""}
${reportData.conditions.critical > 0 ? "- URGENT: Address critical alerts immediately" : ""}
${reportData.predictions.medium > 0 ? "- AI model detected medium risk. Increase monitoring frequency." : ""}
${reportData.conditions.medium > 0 ? "- Monitor sensors with medium risk readings closely" : ""}
${reportData.conditions.critical === 0 && reportData.conditions.medium === 0 && reportData.predictions.critical === 0 && reportData.predictions.medium === 0 ? "- All systems operating normally. Continue routine monitoring." : ""}
- AI Model Confidence: ${reportData.avgConfidence}% (${Number.parseFloat(reportData.avgConfidence) > 90 ? "High" : Number.parseFloat(reportData.avgConfidence) > 75 ? "Medium" : "Review Required"})

════════════════════════════════════════════════════════════════════
Report Generated by AI Rockfall Prediction System
Model Version: v3.2.1 | Total System Alerts: ${reportData.totalAlerts}
For Emergency Support: Contact Mining Operations Manager
════════════════════════════════════════════════════════════════════
    `.trim()

    const blob = new Blob([reportText], { type: "text/plain" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `ai-ml-report-${new Date().getTime()}.txt`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">AI Model Configuration</h1>
          <p className="text-muted-foreground">Real-time sensor monitoring, ML predictions, and AI-powered reports</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-card border border-border rounded-lg p-4 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <p className="text-muted-foreground text-sm">Model Accuracy</p>
              <Brain size={18} className="text-accent" />
            </div>
            <p className="text-2xl font-bold text-accent mt-2">
              {mlPredictions.length > 0 ? `${modelAccuracy}%` : "N/A"}
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              {mlPredictions.length > 0 ? `Based on ${mlPredictions.length} predictions` : "No predictions yet"}
            </p>
          </div>

          <div className="bg-card border border-border rounded-lg p-4 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <p className="text-muted-foreground text-sm">Total Alerts</p>
              <AlertCircle size={18} className="text-orange-500" />
            </div>
            {alertsLoading ? (
              <p className="text-2xl font-bold text-foreground mt-2 animate-pulse">...</p>
            ) : (
              <>
                <p className="text-2xl font-bold text-foreground mt-2">{totalAlerts}</p>
                <p className="text-xs text-muted-foreground mt-2">From database</p>
              </>
            )}
          </div>

          <div className="bg-card border border-border rounded-lg p-4 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <p className="text-muted-foreground text-sm">Last 5-Min Activity</p>
              <Clock size={18} className="text-blue-500" />
            </div>
            <p className="text-2xl font-bold text-foreground mt-2">{last5MinPredictions.length}</p>
            <p className="text-xs text-muted-foreground mt-2">ML predictions</p>
          </div>

          <div className="bg-card border border-border rounded-lg p-4 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <p className="text-muted-foreground text-sm">Sensor Inputs</p>
              <Zap size={18} className="text-green-500" />
            </div>
            <p className="text-2xl font-bold text-foreground mt-2">{sensorActivity.length}</p>
            <p className="text-xs text-muted-foreground mt-2">Total readings</p>
          </div>
        </div>

        <div className="bg-gradient-to-r from-accent/10 via-accent/5 to-accent/10 border border-accent/30 rounded-lg p-6 mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <TrendingUp size={20} className="text-accent" />
            Real-Time Sensor Inputs (Last 10 Readings)
            <span className="ml-auto flex items-center gap-2 text-sm font-normal">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
              </span>
              LIVE
            </span>
          </h3>
          {recentSensorInputs.length > 0 ? (
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {recentSensorInputs.map((input, idx) => {
                const halfThreshold = input.threshold / 2
                let severity: "normal" | "medium" | "critical" = "normal"
                let bgColor = "bg-green-50 dark:bg-green-950/50 border-green-300"
                let dotColor = "bg-green-500"

                if (input.value < halfThreshold) {
                  severity = "normal"
                  bgColor = "bg-green-50 dark:bg-green-950/50 border-green-300"
                  dotColor = "bg-green-500"
                } else if (input.value >= halfThreshold && input.value < input.threshold) {
                  severity = "medium"
                  bgColor = "bg-yellow-50 dark:bg-yellow-950/50 border-yellow-300"
                  dotColor = "bg-yellow-500"
                } else {
                  severity = "critical"
                  bgColor = "bg-red-50 dark:bg-red-950/50 border-red-300"
                  dotColor = "bg-red-500"
                }

                return (
                  <div
                    key={`${input.benchId}-${input.sensorId}-${idx}`}
                    className={`${bgColor} border rounded-lg p-3 flex items-center justify-between`}
                  >
                    <div className="flex items-center gap-3 flex-1">
                      <div className={`w-2 h-2 rounded-full ${dotColor} animate-pulse`} />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm text-foreground">{input.sensorName}</span>
                          <span className="text-xs text-muted-foreground">({input.benchId})</span>
                        </div>
                        <div className="flex items-center gap-4 mt-1 text-xs">
                          <span className="text-foreground">
                            Value:{" "}
                            <strong>
                              {input.value} {input.unit}
                            </strong>
                          </span>
                          <span className="text-muted-foreground">
                            Threshold: {input.threshold} {input.unit}
                          </span>
                          <span
                            className={`font-bold uppercase ${
                              severity === "critical"
                                ? "text-red-600"
                                : severity === "medium"
                                  ? "text-yellow-600"
                                  : "text-green-600"
                            }`}
                          >
                            {severity}
                          </span>
                        </div>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">
                      {new Date(input.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                )
              })}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <AlertCircle size={40} className="mx-auto mb-3 opacity-50" />
              <p>No sensor inputs yet. Start entering sensor readings to see real-time data.</p>
            </div>
          )}
        </div>

        <div className="bg-accent/10 border border-accent/30 rounded-lg p-6 mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <Activity size={20} />
            AI-Generated Report & Analysis
          </h3>
          <div className="bg-card border border-border rounded-lg p-4 mb-4">
            <p className="text-sm text-muted-foreground mb-3">
              This AI-powered report analyzes the last 5 minutes of sensor activity, ML predictions, and generates
              actionable insights based on your current system state.
            </p>
            <div className="flex gap-2 mb-4">
              <button
                onClick={() => setReportMode("aiReport")}
                className={`px-4 py-2 rounded text-sm font-medium transition-colors flex items-center gap-2 ${
                  reportMode === "aiReport"
                    ? "bg-accent text-accent-foreground"
                    : "bg-secondary text-foreground hover:bg-secondary/80"
                }`}
              >
                <Clock size={16} />
                Last 5-Min Activity
              </button>
              <button
                onClick={() => setReportMode("threshold")}
                className={`px-4 py-2 rounded text-sm font-medium transition-colors ${
                  reportMode === "threshold"
                    ? "bg-accent text-accent-foreground"
                    : "bg-secondary text-foreground hover:bg-secondary/80"
                }`}
              >
                Threshold Settings
              </button>
            </div>
          </div>

          {reportMode === "aiReport" && (
            <div className="space-y-4">
              <div className="bg-secondary/30 border border-border rounded-lg p-4">
                <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                  <Brain size={18} className="text-accent" />
                  AI Model Predictions (Last 5 Minutes)
                </h4>
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="bg-card border border-green-500/30 rounded p-3 text-center">
                    <p className="text-muted-foreground text-xs">Normal</p>
                    <p className="text-2xl font-bold text-green-600 mt-1">
                      {last5MinPredictions.filter((p) => p.predicted_risk === "normal").length}
                    </p>
                  </div>
                  <div className="bg-card border border-yellow-500/30 rounded p-3 text-center">
                    <p className="text-muted-foreground text-xs">Medium Risk</p>
                    <p className="text-2xl font-bold text-yellow-600 mt-1">
                      {last5MinPredictions.filter((p) => p.predicted_risk === "medium").length}
                    </p>
                  </div>
                  <div className="bg-card border border-red-500/30 rounded p-3 text-center">
                    <p className="text-muted-foreground text-xs">Critical</p>
                    <p className="text-2xl font-bold text-red-600 mt-1">
                      {last5MinPredictions.filter((p) => p.predicted_risk === "critical").length}
                    </p>
                  </div>
                </div>
                {last5MinPredictions.length > 0 ? (
                  <div className="bg-card border border-border rounded p-3 max-h-60 overflow-y-auto">
                    <p className="text-xs font-semibold text-muted-foreground mb-2">RECENT ML PREDICTIONS:</p>
                    {last5MinPredictions
                      .slice(-5)
                      .reverse()
                      .map((pred) => (
                        <div key={pred.id} className="text-xs mb-3 pb-3 border-b border-border last:border-b-0">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-muted-foreground">
                              {new Date(pred.created_at).toLocaleTimeString()}
                            </span>
                            <span
                              className={`font-bold px-2 py-0.5 rounded ${
                                pred.predicted_risk === "critical"
                                  ? "bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400"
                                  : pred.predicted_risk === "medium"
                                    ? "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400"
                                    : "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400"
                              }`}
                            >
                              {pred.predicted_risk.toUpperCase()}
                            </span>
                          </div>
                          <p className="text-foreground mb-1">
                            <strong>{pred.sensor_name}</strong>: {pred.input_value}
                          </p>
                          <p className="text-muted-foreground text-[10px]">
                            Confidence: {pred.confidence}% • {pred.recommendation}
                          </p>
                        </div>
                      ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground italic text-center py-4">
                    No ML predictions in the last 5 minutes
                  </p>
                )}
              </div>

              <div className="bg-secondary/30 border border-border rounded-lg p-4">
                <h4 className="font-semibold text-foreground mb-3">Alert Events (Last 5 Minutes)</h4>
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="bg-card border border-border rounded p-3 text-center">
                    <p className="text-muted-foreground text-xs">Normal</p>
                    <p className="text-2xl font-bold text-green-600 mt-1">
                      {last5MinActivity.filter((a) => a.severity === "normal").length}
                    </p>
                  </div>
                  <div className="bg-card border border-border rounded p-3 text-center">
                    <p className="text-muted-foreground text-xs">Medium Risk</p>
                    <p className="text-2xl font-bold text-yellow-600 mt-1">
                      {last5MinActivity.filter((a) => a.severity === "medium").length}
                    </p>
                  </div>
                  <div className="bg-card border border-border rounded p-3 text-center">
                    <p className="text-muted-foreground text-xs">Critical</p>
                    <p className="text-2xl font-bold text-red-600 mt-1">
                      {last5MinActivity.filter((a) => a.severity === "critical").length}
                    </p>
                  </div>
                </div>
                {last5MinActivity.length > 0 ? (
                  <div className="bg-card border border-border rounded p-3 max-h-40 overflow-y-auto">
                    <p className="text-xs font-semibold text-muted-foreground mb-2">RECENT EVENTS:</p>
                    {last5MinActivity.slice(-5).map((activity) => (
                      <div key={activity.id} className="text-xs mb-2 pb-2 border-b border-border last:border-b-0">
                        <span className="text-muted-foreground">
                          {new Date(activity.timestamp).toLocaleTimeString()}
                        </span>
                        <span className="text-foreground ml-2">
                          {activity.benchId} • {activity.sensorName}: {activity.value}/{activity.threshold}
                        </span>
                        <span
                          className={`ml-2 font-semibold ${
                            activity.severity === "critical"
                              ? "text-red-600"
                              : activity.severity === "medium"
                                ? "text-yellow-600"
                                : "text-green-600"
                          }`}
                        >
                          [{activity.severity.toUpperCase()}]
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground italic">No events in the last 5 minutes</p>
                )}
              </div>

              <button
                onClick={handleDownloadAIReport}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-accent text-accent-foreground rounded-lg hover:opacity-90 transition-opacity font-medium"
              >
                <Download size={18} />
                Download Complete AI Report (Last 5 Min)
              </button>
            </div>
          )}
        </div>

        {reportMode === "threshold" && (
          <>
            {/* Threshold Management */}
            <div>
              <h2 className="text-xl font-semibold text-foreground mb-4">Sensor Thresholds</h2>
              <div className="space-y-2">
                {benches.map((bench) => (
                  <div key={bench.id} className="bg-card border border-border rounded-lg overflow-hidden">
                    {/* Bench Header */}
                    <button
                      onClick={() => setExpandedSensor(expandedSensor === bench.id ? null : bench.id)}
                      className="w-full px-4 py-3 flex items-center justify-between hover:bg-secondary/50 transition-colors"
                    >
                      <span className="font-semibold text-foreground">{bench.name}</span>
                      {expandedSensor === bench.id ? (
                        <ChevronUp size={20} className="text-accent" />
                      ) : (
                        <ChevronDown size={20} className="text-muted-foreground" />
                      )}
                    </button>

                    {/* Sensors List */}
                    {expandedSensor === bench.id && (
                      <div className="border-t border-border bg-secondary/30 px-4 py-3 space-y-3">
                        {bench.sensors.map((sensor) => (
                          <div
                            key={sensor.id}
                            className="flex items-center justify-between bg-card p-3 rounded-lg border border-border"
                          >
                            <div>
                              <p className="font-medium text-foreground">{sensor.name}</p>
                              <p className="text-xs text-muted-foreground">ID: {sensor.id}</p>
                            </div>

                            {editingThreshold === sensor.id ? (
                              <div className="flex items-center gap-2">
                                <input
                                  type="number"
                                  value={newThresholdValue}
                                  onChange={(e) => setNewThresholdValue(e.target.value)}
                                  className="w-20 px-2 py-1 bg-input border border-border rounded text-foreground text-sm"
                                  autoFocus
                                />
                                <button
                                  onClick={() => handleThresholdUpdate(sensor.id, Number.parseFloat(newThresholdValue))}
                                  className="px-2 py-1 bg-accent text-accent-foreground rounded text-xs font-medium hover:opacity-90"
                                >
                                  Save
                                </button>
                                <button
                                  onClick={() => {
                                    setEditingThreshold(null)
                                    setNewThresholdValue("")
                                  }}
                                  className="px-2 py-1 bg-muted text-foreground rounded text-xs font-medium hover:opacity-90"
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-accent text-lg">{sensor.threshold}</span>
                                <button
                                  onClick={() => {
                                    setEditingThreshold(sensor.id)
                                    setNewThresholdValue(sensor.threshold.toString())
                                  }}
                                  className="px-3 py-1 bg-secondary text-foreground rounded text-sm hover:bg-secondary/80 transition-colors"
                                >
                                  Edit
                                </button>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
