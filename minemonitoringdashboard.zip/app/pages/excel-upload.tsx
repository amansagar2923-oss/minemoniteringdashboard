"use client"

import type React from "react"

import { useState } from "react"
import { Upload, FileSpreadsheet, CheckCircle, AlertCircle, Download } from "lucide-react"
import { useThresholds } from "@/hooks/use-thresholds"
import { useTranslation } from "@/lib/use-translation"

export function ExcelUploadView() {
  const { t } = useTranslation()
  const { thresholds, loading, refetch } = useThresholds()
  const [uploading, setUploading] = useState(false)
  const [uploadStatus, setUploadStatus] = useState<{
    type: "success" | "error" | null
    message: string
  }>({ type: null, message: "" })

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validate file type
    const validTypes = [".csv", ".txt"]
    const fileExtension = file.name.substring(file.name.lastIndexOf(".")).toLowerCase()

    if (!validTypes.includes(fileExtension)) {
      setUploadStatus({
        type: "error",
        message: "Invalid file type. Please upload CSV or TXT file.",
      })
      return
    }

    try {
      setUploading(true)
      setUploadStatus({ type: null, message: "" })

      const formData = new FormData()
      formData.append("file", file)

      const response = await fetch("/api/excel/upload", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.success) {
        setUploadStatus({
          type: "success",
          message: data.message,
        })
        refetch() // Refresh thresholds
      } else {
        setUploadStatus({
          type: "error",
          message: data.error || "Upload failed",
        })
      }
    } catch (error: any) {
      setUploadStatus({
        type: "error",
        message: error.message || "Upload failed",
      })
    } finally {
      setUploading(false)
      e.target.value = "" // Reset input
    }
  }

  const downloadTemplate = () => {
    const template = `sensor_id,sensor_name,threshold_value,unit,bench_id
b1-s1,Vibration,50,mm/s,Bench 1
b1-s2,Humidity,60,%,Bench 1
b1-s3,Temperature,70,°C,Bench 1
b1-s4,Pore Pressure,80,kPa,Bench 1
b2-s1,Vibration,55,mm/s,Bench 2
b2-s2,Humidity,65,%,Bench 2
b2-s3,Temperature,75,°C,Bench 2
b2-s4,Pore Pressure,85,kPa,Bench 2`

    const blob = new Blob([template], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "threshold-template.csv"
    a.click()
    window.URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Excel Threshold Management</h1>
          <p className="text-muted-foreground">Upload Excel/CSV files to update sensor thresholds</p>
        </div>

        {/* Upload Section */}
        <div className="bg-card border border-border rounded-lg p-6 mb-8">
          <div className="flex items-center gap-2 mb-4">
            <FileSpreadsheet className="text-accent" size={24} />
            <h2 className="text-xl font-semibold text-foreground">Upload Threshold File</h2>
          </div>

          <div className="bg-secondary/30 border-2 border-dashed border-border rounded-lg p-8 text-center">
            <Upload className="mx-auto mb-4 text-muted-foreground" size={48} />

            <label className="cursor-pointer">
              <span className="bg-accent text-accent-foreground px-6 py-3 rounded-lg inline-flex items-center gap-2 hover:opacity-90 transition-opacity">
                <Upload size={18} />
                {uploading ? "Uploading..." : "Choose CSV File"}
              </span>
              <input
                type="file"
                accept=".csv,.txt"
                onChange={handleFileUpload}
                disabled={uploading}
                className="hidden"
              />
            </label>

            <p className="text-sm text-muted-foreground mt-4">Supported formats: CSV, TXT (comma-separated)</p>

            <button
              onClick={downloadTemplate}
              className="mt-4 text-sm text-accent hover:underline flex items-center gap-1 mx-auto"
            >
              <Download size={14} />
              Download Template
            </button>
          </div>

          {/* Upload Status */}
          {uploadStatus.type && (
            <div
              className={`mt-4 p-4 rounded-lg flex items-start gap-3 ${
                uploadStatus.type === "success"
                  ? "bg-green-500/10 border border-green-500/30"
                  : "bg-red-500/10 border border-red-500/30"
              }`}
            >
              {uploadStatus.type === "success" ? (
                <CheckCircle className="text-green-600 flex-shrink-0" size={20} />
              ) : (
                <AlertCircle className="text-red-600 flex-shrink-0" size={20} />
              )}
              <div>
                <p className={`font-semibold ${uploadStatus.type === "success" ? "text-green-600" : "text-red-600"}`}>
                  {uploadStatus.type === "success" ? "Success!" : "Error"}
                </p>
                <p className="text-sm text-foreground mt-1">{uploadStatus.message}</p>
              </div>
            </div>
          )}
        </div>

        {/* Current Thresholds */}
        <div className="bg-card border border-border rounded-lg p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Current Thresholds</h2>

          {loading ? (
            <p className="text-muted-foreground text-center py-8">Loading thresholds...</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 text-sm font-semibold text-muted-foreground">Bench</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-muted-foreground">Sensor ID</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-muted-foreground">Sensor Name</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-muted-foreground">Threshold</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-muted-foreground">Unit</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-muted-foreground">Last Updated</th>
                  </tr>
                </thead>
                <tbody>
                  {thresholds.map((threshold) => (
                    <tr key={threshold.id} className="border-b border-border hover:bg-secondary/30">
                      <td className="py-3 px-4 text-sm text-foreground">{threshold.bench_id}</td>
                      <td className="py-3 px-4 text-sm text-muted-foreground font-mono">{threshold.sensor_id}</td>
                      <td className="py-3 px-4 text-sm text-foreground">{threshold.sensor_name}</td>
                      <td className="py-3 px-4 text-sm font-bold text-accent">{threshold.threshold_value}</td>
                      <td className="py-3 px-4 text-sm text-muted-foreground">{threshold.unit}</td>
                      <td className="py-3 px-4 text-sm text-muted-foreground">
                        {new Date(threshold.updated_at).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Instructions */}
        <div className="mt-8 bg-accent/10 border border-accent/30 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-3">File Format Instructions</h3>
          <div className="text-sm text-foreground space-y-2">
            <p>Your CSV file must have the following columns (in order):</p>
            <ol className="list-decimal list-inside space-y-1 ml-4">
              <li>
                <code className="bg-secondary px-2 py-0.5 rounded">sensor_id</code> - Unique sensor identifier (e.g.,
                b1-s1)
              </li>
              <li>
                <code className="bg-secondary px-2 py-0.5 rounded">sensor_name</code> - Name of the sensor (e.g.,
                Vibration)
              </li>
              <li>
                <code className="bg-secondary px-2 py-0.5 rounded">threshold_value</code> - Numeric threshold value
              </li>
              <li>
                <code className="bg-secondary px-2 py-0.5 rounded">unit</code> - Measurement unit (e.g., mm/s, %, °C)
              </li>
              <li>
                <code className="bg-secondary px-2 py-0.5 rounded">bench_id</code> - Bench identifier (e.g., Bench 1)
              </li>
            </ol>
            <p className="mt-4 text-muted-foreground italic">Download the template to see an example format.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
