"use client"

import { useState } from "react"
import { Mine3D } from "@/components/mine-3d"
import { MineMap } from "@/components/mine-map"
import { ZoomIn, ZoomOut, RotateCcw } from "lucide-react"

export function MineMapView() {
  const [rotation, setRotation] = useState({ x: 0.4, y: 0.8 })
  const [zoom, setZoom] = useState(1)

  const handleRotate = () => {
    setRotation({ x: 0.4, y: (rotation.y + Math.PI / 4) % (Math.PI * 2) })
  }

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 0.2, 3))
  }

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 0.2, 0.5))
  }

  const handleResetView = () => {
    setRotation({ x: 0.4, y: 0.8 })
    setZoom(1)
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="flex h-[calc(100vh-64px)]">
        {/* Left Panel - 3D Mine */}
        <div className="flex-1 border-r border-border relative bg-card">
          <div className="absolute top-4 right-4 z-10 flex gap-2">
            <button
              onClick={handleRotate}
              className="p-2 bg-accent text-accent-foreground rounded-lg hover:opacity-90 transition-opacity"
              title="Rotate view"
            >
              <RotateCcw size={18} />
            </button>
            <button
              onClick={handleZoomIn}
              className="p-2 bg-accent text-accent-foreground rounded-lg hover:opacity-90 transition-opacity"
              title="Zoom in"
            >
              <ZoomIn size={18} />
            </button>
            <button
              onClick={handleZoomOut}
              className="p-2 bg-accent text-accent-foreground rounded-lg hover:opacity-90 transition-opacity"
              title="Zoom out"
            >
              <ZoomOut size={18} />
            </button>
          </div>

          <Mine3D rotation={rotation} zoom={zoom} />
        </div>

        {/* Right Panel - Map */}
        <div className="flex-1 bg-card flex flex-col">
          <div className="p-4 border-b border-border">
            <h2 className="text-lg font-semibold text-foreground">Singrauli DEM & Map</h2>
            <p className="text-sm text-muted-foreground">Real-time risk overlay</p>
          </div>
          <div className="flex-1 overflow-hidden">
            <MineMap />
          </div>
        </div>
      </div>
    </div>
  )
}
