"use client"

import { useTranslation } from "@/lib/use-translation"
import { Bell, Trash2, AlertCircle, AlertTriangle, CheckCircle2 } from "lucide-react"
import { useState } from "react"
import { useAlerts } from "@/hooks/use-alerts"

export function NotificationsView() {
  const { t } = useTranslation()
  const { alerts, loading, unreadCount, markAsRead, markAllAsRead } = useAlerts()
  const [deletedAlerts, setDeletedAlerts] = useState<Set<string>>(new Set())

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "normal":
        return <CheckCircle2 className="text-green-600" size={20} />
      case "medium":
        return <AlertTriangle className="text-yellow-600" size={20} />
      case "critical":
        return <AlertCircle className="text-red-600" size={20} />
      default:
        return <Bell size={20} />
    }
  }

  const getSeverityBg = (severity: string) => {
    switch (severity) {
      case "normal":
        return "bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800"
      case "medium":
        return "bg-yellow-50 dark:bg-yellow-950 border-yellow-200 dark:border-yellow-800"
      case "critical":
        return "bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800"
      default:
        return "bg-card border-border"
    }
  }

  const activeAlerts = alerts.filter((alert) => !deletedAlerts.has(alert.id))

  const deleteAlert = (alertId: string) => {
    setDeletedAlerts((prev) => new Set([...prev, alertId]))
    markAsRead(alertId)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading alerts...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">{t("notifications.title")}</h1>
            <p className="text-muted-foreground">
              {activeAlerts.length} active alerts | {unreadCount} unread
            </p>
          </div>
          {unreadCount > 0 && (
            <button
              onClick={markAllAsRead}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors text-sm font-medium"
            >
              Mark all as read
            </button>
          )}
        </div>

        {activeAlerts.length === 0 ? (
          <div className="bg-card border border-border rounded-lg p-12 text-center">
            <Bell className="mx-auto text-muted-foreground mb-4" size={48} />
            <p className="text-foreground font-semibold mb-2">{t("notifications.noAlertsTitle")}</p>
            <p className="text-muted-foreground">
              {deletedAlerts.size > 0 ? t("notifications.allAlertsCleared") : t("notifications.allSystemsNormal")}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {activeAlerts.map((alert) => (
              <div
                key={alert.id}
                className={`border rounded-lg p-4 flex items-start justify-between transition-all ${getSeverityBg(alert.severity)} ${!alert.read ? "ring-2 ring-primary/50" : ""}`}
              >
                <div className="flex items-start gap-4 flex-1">
                  <div className="pt-1">{getSeverityIcon(alert.severity)}</div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-foreground text-base">{alert.sensor_name}</h3>
                        <p className="text-sm text-muted-foreground mt-1">{alert.message}</p>
                      </div>
                      <span
                        className={`text-xs font-semibold px-3 py-1 rounded whitespace-nowrap ml-2 ${
                          alert.severity === "normal"
                            ? "bg-green-200 text-green-800 dark:bg-green-900 dark:text-green-200"
                            : alert.severity === "medium"
                              ? "bg-yellow-200 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
                              : "bg-red-200 text-red-800 dark:bg-red-900 dark:text-red-200"
                        }`}
                      >
                        {alert.severity.toUpperCase()}
                      </span>
                    </div>

                    {/* Reading Details */}
                    <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-3 bg-white/30 dark:bg-black/20 rounded-lg p-3 border border-white/10">
                      <div className="text-center">
                        <p className="text-xs opacity-75 mb-1">{t("notifications.currentValue")}</p>
                        <p className="font-bold text-sm">{alert.sensor_value}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs opacity-75 mb-1">{t("notifications.threshold")}</p>
                        <p className="font-bold text-sm">{alert.threshold}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs opacity-75 mb-1">{t("notifications.variance")}</p>
                        <p className="font-bold text-sm">
                          {((alert.sensor_value / alert.threshold) * 100).toFixed(1)}%
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs opacity-75 mb-1">{t("notifications.timestamp")}</p>
                        <p className="font-bold text-xs">{new Date(alert.created_at).toLocaleTimeString()}</p>
                      </div>
                    </div>

                    {/* Timestamp */}
                    <p className="text-xs text-muted-foreground mt-3 opacity-75">
                      {t("notifications.alertId")}: {alert.id.slice(0, 8)} | {t("notifications.date")}:{" "}
                      {new Date(alert.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => deleteAlert(alert.id)}
                  className="ml-4 p-2 hover:bg-black/10 dark:hover:bg-white/10 rounded transition-colors flex-shrink-0"
                  title={t("notifications.deleteAlert")}
                >
                  <Trash2 size={18} className="text-muted-foreground" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
