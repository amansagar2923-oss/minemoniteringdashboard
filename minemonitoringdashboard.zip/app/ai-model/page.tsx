"use client"

import { Navbar } from "@/components/navbar"
import { MineProvider } from "@/lib/context"
import { AIModelView } from "@/app/pages/ai-model"

export default function Page() {
  return (
    <MineProvider>
      <Navbar />
      <AIModelView />
    </MineProvider>
  )
}
