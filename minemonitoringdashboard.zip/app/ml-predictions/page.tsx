import { MLPredictionsView } from "@/app/pages/ml-predictions"

export default function MLPredictionsPage() {
  return <MLPredictionsView />
}
