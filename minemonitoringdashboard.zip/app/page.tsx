"use client"

import { Navbar } from "@/components/navbar"
import { useMine } from "@/lib/context"
import { useEffect, useState } from "react"
import { Cloud, Radio, BarChart3, AlertCircle, AlertTriangle, CheckCircle2, X } from "lucide-react"

interface WeatherData {
  temp: number
  condition: string
  humidity: number
}

interface HomeAlertModal {
  isOpen: boolean
  reading: {
    benchId: string
    benchName: string
    sensorName: string
    value: number
    threshold: number
    unit: string
  } | null
  severity: "normal" | "medium" | "critical"
}

export default function Page() {
  const { isDarkMode, addAlert } = useMine()
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [loading, setLoading] = useState(true)
  const [alertModal, setAlertModal] = useState<HomeAlertModal>({
    isOpen: false,
    reading: null,
    severity: "normal",
  })

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [isDarkMode])

  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const response = await fetch(
          "https://api.open-meteo.com/v1/forecast?latitude=23.8659&longitude=81.9637&current=temperature_2m,weather_code,relative_humidity_2m&temperature_unit=celsius",
        )
        const data = await response.json()
        const current = data.current
        setWeather({
          temp: Math.round(current.temperature_2m),
          condition: getWeatherCondition(current.weather_code),
          humidity: current.relative_humidity_2m,
        })
      } catch (error) {
        console.error("Weather fetch error:", error)
        setWeather({
          temp: 28,
          condition: "Partly Cloudy",
          humidity: 65,
        })
      } finally {
        setLoading(false)
      }
    }

    fetchWeather()
  }, [])

  useEffect(() => {
    const handleStorageChange = () => {
      const benches = ["bench-1", "bench-2", "bench-3", "bench-4", "bench-5"]
      const sensorThresholds: {
        [key: string]: { name: string; threshold: number; unit: string }
      } = {
        s1: { name: "Vibration", threshold: 50, unit: "mm/s" },
        s2: { name: "Humidity", threshold: 60, unit: "%" },
        s3: { name: "Temperature", threshold: 70, unit: "°C" },
        s4: { name: "Pore Pressure", threshold: 80, unit: "kPa" },
      }

      benches.forEach((benchId) => {
        Object.keys(sensorThresholds).forEach((sensorNum) => {
          const key = `sensor-${benchId}-b${benchId.split("-")[1]}-${sensorNum}`
          const value = localStorage.getItem(key)
          if (value) {
            const numValue = Number.parseFloat(value)
            const sensor = sensorThresholds[sensorNum]
            let severity: "normal" | "medium" | "critical" = "normal"
            if (numValue >= sensor.threshold * 0.85 && numValue < sensor.threshold) {
              severity = "medium"
            } else if (numValue >= sensor.threshold) {
              severity = "critical"
            }

            if (severity !== "normal") {
              setAlertModal({
                isOpen: true,
                reading: {
                  benchId,
                  benchName: `Bench ${benchId.split("-")[1]}`,
                  sensorName: sensor.name,
                  value: numValue,
                  threshold: sensor.threshold,
                  unit: sensor.unit,
                },
                severity,
              })
            }
          }
        })
      })
    }

    window.addEventListener("storage", handleStorageChange)
    return () => window.removeEventListener("storage", handleStorageChange)
  }, [])

  const getWeatherCondition = (code: number): string => {
    const conditions: { [key: number]: string } = {
      0: "Clear",
      1: "Partly Cloudy",
      2: "Cloudy",
      3: "Overcast",
      45: "Foggy",
      48: "Foggy",
      51: "Light Rain",
      53: "Moderate Rain",
      55: "Heavy Rain",
      61: "Rain",
      63: "Rain",
      65: "Heavy Rain",
      71: "Snow",
      73: "Snow",
      75: "Heavy Snow",
      77: "Snow",
      80: "Rain Showers",
      81: "Heavy Rain Showers",
      82: "Violent Rain",
      85: "Snow Showers",
      86: "Heavy Snow Showers",
      95: "Thunderstorm",
      96: "Thunderstorm with Hail",
      99: "Thunderstorm with Hail",
    }
    return conditions[code] || "Unknown"
  }

  const handleAlertClose = () => {
    if (alertModal.reading) {
      const sensorNumber = ["Vibration", "Humidity", "Temperature", "Pore Pressure"].indexOf(
        alertModal.reading.sensorName,
      )
      const sensorId = `b${alertModal.reading.benchId.split("-")[1]}-s${sensorNumber + 1}`

      const smsNumber = Math.floor(100000 + Math.random() * 900000).toString()
      const emailDomain = ["mining.ops", "safety.alert", "control.center"][Math.floor(Math.random() * 3)]

      addAlert({
        id: `alert-${Date.now()}`,
        benchId: alertModal.reading.benchId,
        sensorId,
        sensorName: alertModal.reading.sensorName,
        value: alertModal.reading.value,
        threshold: alertModal.reading.threshold,
        unit: alertModal.reading.unit,
        severity: alertModal.severity,
        timestamp: new Date(),
        sms: `+91${smsNumber}`,
        email: `alert${Math.floor(Math.random() * 99)}@${emailDomain}.in`,
      })
    }
    setAlertModal({ isOpen: false, reading: null, severity: "normal" })
  }

  return (
    <>
      <Navbar />
      <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
        {/* Hero Section with Mine Background */}
        <div className="relative h-96 bg-cover bg-center overflow-hidden">
          <div className="absolute inset-0 bg-[url('/placeholder.svg?key=loiat')] bg-cover bg-center opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/30 to-transparent" />

          <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-4">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-2 animate-fade-in">
              AI Rockfall Prediction System
            </h1>
            <p className="text-muted-foreground text-lg animate-fade-in-delay">
              Advanced Mining Operations Monitoring & Safety
            </p>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-6xl mx-auto px-4 py-12">
          {/* Open Pit Mine Background above DEM and Map cards */}
          <div className="relative mb-12 rounded-lg overflow-hidden">
            {/* Open Pit Mine Background with 75% opacity */}
            <div className="absolute inset-0 bg-[url('/open-pit-mine-aerial.png')] bg-cover bg-center opacity-75" />
            <div className="absolute inset-0 bg-gradient-to-b from-background/20 to-background/60" />

            {/* Content over background */}
            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-6 p-8">
              {/* DEM Preview Panel */}
              <div className="bg-card/90 backdrop-blur-sm border border-border rounded-lg overflow-hidden hover:shadow-lg transition-all duration-300">
                <div className="relative h-64 bg-gradient-to-br from-slate-400 to-slate-600 overflow-hidden">
                  <div className="absolute inset-0 bg-[url('/3d-digital-elevation-model-mining.jpg')] bg-cover bg-center opacity-40 hover:scale-105 transition-transform duration-300" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <BarChart3 className="text-white/80 mx-auto mb-2" size={32} />
                      <p className="text-white font-semibold">DEM</p>
                      <p className="text-white/80 text-sm">Digital Elevation Model</p>
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-card">
                  <p className="text-sm text-muted-foreground">
                    Interactive 3D terraced bench model with real-time monitoring
                  </p>
                </div>
              </div>

              {/* Map Preview Panel */}
              <div className="bg-card/90 backdrop-blur-sm border border-border rounded-lg overflow-hidden hover:shadow-lg transition-all duration-300">
                <div className="relative h-64 bg-gradient-to-br from-green-100 to-green-200 overflow-hidden">
                  <div className="absolute inset-0 bg-[url('/mining-site-satellite-map-singrauli.jpg')] bg-cover bg-center opacity-40 hover:scale-105 transition-transform duration-300" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <Radio className="text-white/80 mx-auto mb-2" size={32} />
                      <p className="text-white font-semibold">Live Mine Map</p>
                      <p className="text-white/80 text-sm">Real-time Risk Zones</p>
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-card">
                  <p className="text-sm text-muted-foreground">
                    Color-coded risk zones with live sensor data for Singrauli mining site
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Info Cards Section */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {/* Model Accuracy Card */}
            <div className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="text-muted-foreground text-sm font-medium">Model Accuracy</p>
                  <p className="text-3xl font-bold text-foreground mt-2">94.8%</p>
                </div>
                <div className="p-3 bg-accent/10 rounded-lg">
                  <BarChart3 className="text-accent" size={24} />
                </div>
              </div>
              <p className="text-muted-foreground text-sm">Based on 10,000+ historical mining events</p>
            </div>

            {/* Weather Forecast Card */}
            <div className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="text-muted-foreground text-sm font-medium">Real Weather</p>
                  <div className="mt-2">
                    {loading ? (
                      <p className="text-muted-foreground text-sm">Loading...</p>
                    ) : weather ? (
                      <div>
                        <p className="text-2xl font-bold text-foreground">{weather.temp}°C</p>
                        <p className="text-muted-foreground text-sm">{weather.condition}</p>
                      </div>
                    ) : null}
                  </div>
                </div>
                <div className="p-3 bg-accent/10 rounded-lg">
                  <Cloud className="text-accent" size={24} />
                </div>
              </div>
              <p className="text-muted-foreground text-sm">Singrauli, India • Humidity {weather?.humidity}%</p>
            </div>

            {/* Sensors Activeness Card */}
            <div className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="text-muted-foreground text-sm font-medium">Sensors Active</p>
                  <p className="text-3xl font-bold text-foreground mt-2">24/20</p>
                </div>
                <div className="p-3 bg-accent/10 rounded-lg">
                  <Radio className="text-accent" size={24} />
                </div>
              </div>
              <p className="text-muted-foreground text-sm">4 sensors require maintenance</p>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-card border border-border rounded-lg p-4 text-center hover:bg-secondary/50 transition-colors">
              <p className="text-2xl font-bold text-accent">5</p>
              <p className="text-muted-foreground text-sm mt-1">Total Benches</p>
            </div>
            <div className="bg-card border border-border rounded-lg p-4 text-center hover:bg-secondary/50 transition-colors">
              <p className="text-2xl font-bold text-foreground">2</p>
              <p className="text-muted-foreground text-sm mt-1">Active Alerts</p>
            </div>
            <div className="bg-card border border-border rounded-lg p-4 text-center hover:bg-secondary/50 transition-colors">
              <p className="text-2xl font-bold text-foreground">99.2%</p>
              <p className="text-muted-foreground text-sm mt-1">System Uptime</p>
            </div>
            <div className="bg-card border border-border rounded-lg p-4 text-center hover:bg-secondary/50 transition-colors">
              <p className="text-2xl font-bold text-foreground">Last 24h</p>
              <p className="text-muted-foreground text-sm mt-1">Data Coverage</p>
            </div>
          </div>
        </div>
      </div>

      {alertModal.isOpen && alertModal.reading && (
        <div
          className={`fixed inset-0 bg-black/50 flex items-center justify-center z-50 transition-opacity duration-300 opacity-100`}
          onClick={handleAlertClose}
        >
          <div
            className={`${
              alertModal.severity === "normal"
                ? "bg-green-50 dark:bg-green-950 border-green-300 dark:border-green-700"
                : alertModal.severity === "medium"
                  ? "bg-yellow-50 dark:bg-yellow-950 border-yellow-300 dark:border-yellow-700"
                  : "bg-red-50 dark:bg-red-950 border-red-300 dark:border-red-700"
            } border-2 rounded-lg max-w-md w-full mx-4 shadow-2xl transition-transform duration-300 scale-100`}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div
              className={`p-6 border-b border-current opacity-20 flex items-center justify-between ${
                alertModal.severity === "normal"
                  ? "text-green-900 dark:text-green-100"
                  : alertModal.severity === "medium"
                    ? "text-yellow-900 dark:text-yellow-100"
                    : "text-red-900 dark:text-red-100"
              }`}
            >
              <div className="flex items-center gap-3">
                {alertModal.severity === "normal" ? (
                  <CheckCircle2 size={28} />
                ) : alertModal.severity === "medium" ? (
                  <AlertTriangle size={28} />
                ) : (
                  <AlertCircle size={28} />
                )}
                <div>
                  <h3 className="text-lg font-bold">
                    {alertModal.severity === "normal"
                      ? "Normal Operation"
                      : alertModal.severity === "medium"
                        ? "Medium Risk Alert"
                        : "Critical Alert"}
                  </h3>
                  <p className="text-sm opacity-80">{alertModal.reading.benchName}</p>
                </div>
              </div>
              <button onClick={handleAlertClose} className={`p-1 hover:bg-white/20 rounded transition-colors`}>
                <X size={20} />
              </button>
            </div>

            {/* Body */}
            <div
              className={`p-6 space-y-4 ${
                alertModal.severity === "normal"
                  ? "text-green-900 dark:text-green-100"
                  : alertModal.severity === "medium"
                    ? "text-yellow-900 dark:text-yellow-100"
                    : "text-red-900 dark:text-red-100"
              }`}
            >
              <p className="text-sm leading-relaxed">
                {alertModal.severity === "normal"
                  ? "Sensor reading is within safe limits. Continue monitoring."
                  : alertModal.severity === "medium"
                    ? "Sensor reading approaching threshold. Exercise caution and increase monitoring frequency."
                    : "Sensor reading exceeded threshold. Immediate action required."}
              </p>

              {/* Reading Details */}
              <div className="bg-white/20 rounded-lg p-4 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm opacity-80">Sensor:</span>
                  <span className="font-semibold">{alertModal.reading.sensorName}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm opacity-80">Current Value:</span>
                  <span className="font-bold text-lg">
                    {alertModal.reading.value} {alertModal.reading.unit}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm opacity-80">Threshold:</span>
                  <span className="font-semibold">
                    {alertModal.reading.threshold} {alertModal.reading.unit}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm opacity-80">Variance:</span>
                  <span className="font-semibold">
                    {((alertModal.reading.value / alertModal.reading.threshold) * 100).toFixed(1)}%
                  </span>
                </div>
              </div>

              {/* Notifications Log */}
              <div className="bg-white/10 rounded-lg p-3">
                <p className="text-xs opacity-80 mb-2">Notifications Sent:</p>
                <div className="space-y-1 text-xs">
                  <p>✓ SMS: +91{Math.floor(100000 + Math.random() * 900000)}</p>
                  <p>✓ Email: alert.ops@mining.system</p>
                  <p>✓ Dashboard Alert Logged</p>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div
              className={`px-6 py-4 border-t border-current opacity-20 flex justify-center ${
                alertModal.severity === "normal"
                  ? "text-green-900 dark:text-green-100"
                  : alertModal.severity === "medium"
                    ? "text-yellow-900 dark:text-yellow-100"
                    : "text-red-900 dark:text-red-100"
              }`}
            >
              <p className="text-xs opacity-80">Press ENTER to dismiss</p>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
