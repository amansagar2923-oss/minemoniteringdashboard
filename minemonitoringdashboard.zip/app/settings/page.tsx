"use client"

import { Navbar } from "@/components/navbar"
import { MineProvider } from "@/lib/context"
import { SettingsView } from "@/app/pages/settings"

export default function Page() {
  return (
    <MineProvider>
      <Navbar />
      <SettingsView />
    </MineProvider>
  )
}
