import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

// Simple ML model simulation (replace with actual model)
function mlPredict(sensorValue: number, threshold: number) {
  const halfThreshold = threshold / 2

  // Calculate risk based on threshold percentage
  const percentage = (sensorValue / threshold) * 100

  let risk: "normal" | "medium" | "critical"
  let confidence: number
  let recommendation: string

  if (sensorValue < halfThreshold) {
    risk = "normal"
    confidence = 95 - (percentage / 50) * 10 // 85-95% confidence
    recommendation = "Continue normal operations. No action required."
  } else if (sensorValue >= halfThreshold && sensorValue < threshold) {
    risk = "medium"
    confidence = 75 + (percentage / 100) * 15 // 75-90% confidence
    recommendation = "Increase monitoring frequency. Prepare contingency measures."
  } else {
    risk = "critical"
    confidence = 90 + (Math.min(percentage - 100, 10) / 10) * 10 // 90-100% confidence
    recommendation = "IMMEDIATE ACTION REQUIRED. Evacuate area and implement emergency protocols."
  }

  return {
    risk,
    confidence: Math.round(confidence * 10) / 10,
    recommendation,
  }
}

// POST predict risk based on sensor input
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { sensor_id, sensor_name, sensor_value } = body

    if (!sensor_id || !sensor_name || sensor_value === undefined) {
      return NextResponse.json({ success: false, error: "Missing required fields" }, { status: 400 })
    }

    const supabase = await createClient()

    // Get threshold from database
    const { data: thresholdData, error: thresholdError } = await supabase
      .from("thresholds")
      .select("threshold_value")
      .eq("sensor_id", sensor_id)
      .single()

    if (thresholdError || !thresholdData) {
      return NextResponse.json({ success: false, error: "Threshold not found for sensor" }, { status: 404 })
    }

    const threshold = thresholdData.threshold_value

    // Run ML prediction
    const prediction = mlPredict(sensor_value, threshold)

    // Save prediction to database
    const { data, error } = await supabase
      .from("ml_predictions")
      .insert({
        sensor_id,
        sensor_name,
        input_value: sensor_value,
        predicted_risk: prediction.risk,
        confidence: prediction.confidence,
        recommendation: prediction.recommendation,
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({
      success: true,
      prediction: {
        ...prediction,
        id: data.id,
        timestamp: data.created_at,
      },
    })
  } catch (error: any) {
    console.error("Error making ML prediction:", error)
    return NextResponse.json({ success: false, error: error.message }, { status: 500 })
  }
}

// GET recent predictions
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    const supabase = await createClient()

    const { data, error } = await supabase
      .from("ml_predictions")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(limit)

    if (error) throw error

    return NextResponse.json({ success: true, predictions: data })
  } catch (error: any) {
    console.error("Error fetching predictions:", error)
    return NextResponse.json({ success: false, error: error.message }, { status: 500 })
  }
}
