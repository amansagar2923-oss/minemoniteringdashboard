import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

// POST upload Excel file and parse thresholds
export async function POST(request: Request) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ success: false, error: "No file uploaded" }, { status: 400 })
    }

    // Read file as text (CSV format)
    const text = await file.text()
    const lines = text.split("\n").filter((line) => line.trim())

    if (lines.length < 2) {
      return NextResponse.json({ success: false, error: "Invalid file format" }, { status: 400 })
    }

    // Parse CSV (expecting: sensor_id, sensor_name, threshold_value, unit, bench_id)
    const headers = lines[0].split(",").map((h) => h.trim())
    const thresholds = []

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(",").map((v) => v.trim())
      if (values.length >= 5) {
        thresholds.push({
          sensor_id: values[0],
          sensor_name: values[1],
          threshold_value: Number.parseFloat(values[2]),
          unit: values[3],
          bench_id: values[4],
        })
      }
    }

    if (thresholds.length === 0) {
      return NextResponse.json({ success: false, error: "No valid threshold data found" }, { status: 400 })
    }

    // Update thresholds in database
    const supabase = await createClient()

    const updates = await Promise.all(
      thresholds.map(async (threshold) => {
        const { data, error } = await supabase
          .from("thresholds")
          .upsert(
            {
              ...threshold,
              updated_at: new Date().toISOString(),
            },
            {
              onConflict: "sensor_id",
            },
          )
          .select()

        if (error) throw error
        return data
      }),
    )

    return NextResponse.json({
      success: true,
      message: `${thresholds.length} thresholds updated from Excel`,
      thresholds: updates.flat(),
    })
  } catch (error: any) {
    console.error("Error uploading Excel file:", error)
    return NextResponse.json({ success: false, error: error.message }, { status: 500 })
  }
}
