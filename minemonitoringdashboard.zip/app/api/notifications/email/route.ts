import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { subject, message, sensor_name, sensor_value, threshold } = body

    const emailUser = process.env.EMAIL_USER
    const emailPassword = process.env.EMAIL_PASSWORD
    const emailTo = process.env.ADMIN_EMAIL

    if (!emailUser || !emailPassword || !emailTo) {
      console.log("[v0] Email credentials not configured. Email not sent.")
      console.log("[v0] Would send email:", { subject, message })
      return NextResponse.json(
        {
          success: false,
          message: "Email not configured",
          simulation: true,
          wouldSend: { subject, message },
        },
        { status: 200 },
      )
    }

    // Using nodemailer with Gmail SMTP
    const nodemailer = require("nodemailer")

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: emailUser,
        pass: emailPassword, // Use App Password for Gmail
      },
    })

    const htmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0;">🚨 CRITICAL ALERT</h1>
        </div>
        <div style="background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px;">
          <h2 style="color: #dc2626; margin-top: 0;">Mining System Alert</h2>
          <p style="font-size: 16px; color: #374151;">${message}</p>
          <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <table style="width: 100%;">
              <tr>
                <td style="padding: 10px; border-bottom: 1px solid #e5e7eb;"><strong>Sensor:</strong></td>
                <td style="padding: 10px; border-bottom: 1px solid #e5e7eb;">${sensor_name}</td>
              </tr>
              <tr>
                <td style="padding: 10px; border-bottom: 1px solid #e5e7eb;"><strong>Current Value:</strong></td>
                <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; color: #dc2626; font-weight: bold;">${sensor_value}</td>
              </tr>
              <tr>
                <td style="padding: 10px;"><strong>Threshold:</strong></td>
                <td style="padding: 10px;">${threshold}</td>
              </tr>
            </table>
          </div>
          <p style="color: #6b7280; font-size: 14px;">This is an automated alert from ABHAY.AI Mining Monitoring System.</p>
        </div>
      </div>
    `

    const mailOptions = {
      from: `"ABHAY.AI Alerts" <${emailUser}>`,
      to: emailTo,
      subject: subject,
      text: message,
      html: htmlContent,
    }

    const info = await transporter.sendMail(mailOptions)
    console.log("[v0] Email sent successfully:", info.messageId)

    return NextResponse.json({ success: true, messageId: info.messageId }, { status: 200 })
  } catch (error) {
    console.error("[v0] Email API error:", error)
    return NextResponse.json({ success: false, error: "Failed to send email" }, { status: 500 })
  }
}
