import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { message, severity } = body

    const accountSid = process.env.TWILIO_ACCOUNT_SID
    const authToken = process.env.TWILIO_AUTH_TOKEN
    const fromNumber = process.env.TWILIO_PHONE_NUMBER
    const toNumber = process.env.ADMIN_PHONE_NUMBER

    if (!accountSid || !authToken || !fromNumber || !toNumber) {
      console.log("[v0] Twilio credentials not configured. SMS not sent.")
      console.log("[v0] Would send SMS:", message)
      return NextResponse.json(
        {
          success: false,
          message: "Twilio not configured",
          simulation: true,
          wouldSend: message,
        },
        { status: 200 },
      )
    }

    // Twilio API call
    const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`
    const params = new URLSearchParams()
    params.append("To", toNumber)
    params.append("From", fromNumber)
    params.append("Body", message)

    const response = await fetch(twilioUrl, {
      method: "POST",
      headers: {
        Authorization: "Basic " + Buffer.from(`${accountSid}:${authToken}`).toString("base64"),
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params,
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error("[v0] Twilio error:", errorData)
      return NextResponse.json({ success: false, error: errorData }, { status: response.status })
    }

    const data = await response.json()
    console.log("[v0] SMS sent successfully:", data.sid)

    return NextResponse.json({ success: true, messageId: data.sid }, { status: 200 })
  } catch (error) {
    console.error("[v0] SMS API error:", error)
    return NextResponse.json({ success: false, error: "Failed to send SMS" }, { status: 500 })
  }
}
