import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

// GET all thresholds
export async function GET() {
  try {
    const supabase = await createClient()

    const { data, error } = await supabase
      .from("thresholds")
      .select("*")
      .order("bench_id", { ascending: true })
      .order("sensor_id", { ascending: true })

    if (error) throw error

    return NextResponse.json({ success: true, thresholds: data })
  } catch (error: any) {
    console.error("Error fetching thresholds:", error)
    return NextResponse.json({ success: false, error: error.message }, { status: 500 })
  }
}

// POST update thresholds (from Excel or manual update)
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { thresholds } = body

    if (!Array.isArray(thresholds)) {
      return NextResponse.json({ success: false, error: "Thresholds must be an array" }, { status: 400 })
    }

    const supabase = await createClient()

    // Update thresholds in batch
    const updates = await Promise.all(
      thresholds.map(async (threshold: any) => {
        const { data, error } = await supabase
          .from("thresholds")
          .upsert({
            sensor_id: threshold.sensor_id,
            sensor_name: threshold.sensor_name,
            threshold_value: threshold.threshold_value,
            unit: threshold.unit,
            bench_id: threshold.bench_id,
            updated_at: new Date().toISOString(),
          })
          .select()

        if (error) throw error
        return data
      }),
    )

    return NextResponse.json({
      success: true,
      message: `${thresholds.length} thresholds updated successfully`,
      updated: updates.flat(),
    })
  } catch (error: any) {
    console.error("Error updating thresholds:", error)
    return NextResponse.json({ success: false, error: error.message }, { status: 500 })
  }
}
