import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const body = await request.json()

    const { sensor_name, sensor_value, threshold, severity, message } = body

    // Validate required fields
    if (!sensor_name || sensor_value === undefined || !threshold || !severity || !message) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const { data: alert, error: dbError } = await supabase
      .from("alerts")
      .insert({
        sensor_name,
        sensor_value,
        threshold,
        severity,
        message,
        read: false,
      })
      .select()
      .single()

    if (dbError) {
      console.error("[v0] Database error:", dbError)
      return NextResponse.json({ error: "Failed to save alert to database", details: dbError.message }, { status: 500 })
    }

    console.log("[v0] Alert saved to database:", alert)

    if (severity === "medium" || severity === "critical") {
      try {
        const smsResponse = await fetch(`${request.nextUrl.origin}/api/notifications/sms`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message: `🚨 ${severity.toUpperCase()} ALERT: ${message}`,
            severity,
          }),
        })

        if (!smsResponse.ok) {
          console.error("[v0] SMS notification failed")
        }
      } catch (smsError) {
        console.error("[v0] SMS error:", smsError)
      }
    }

    if (severity === "critical") {
      try {
        const emailResponse = await fetch(`${request.nextUrl.origin}/api/notifications/email`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            subject: `🚨 CRITICAL ALERT: ${sensor_name}`,
            message,
            sensor_name,
            sensor_value,
            threshold,
          }),
        })

        if (!emailResponse.ok) {
          console.error("[v0] Email notification failed")
        }
      } catch (emailError) {
        console.error("[v0] Email error:", emailError)
      }
    }

    return NextResponse.json({ success: true, alert }, { status: 201 })
  } catch (error) {
    console.error("[v0] Alert API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()

    const { data: alerts, error } = await supabase.from("alerts").select("*").order("created_at", { ascending: false })

    if (error) {
      console.error("[v0] Error fetching alerts:", error)
      return NextResponse.json({ error: "Failed to fetch alerts" }, { status: 500 })
    }

    return NextResponse.json({ alerts }, { status: 200 })
  } catch (error) {
    console.error("[v0] Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
