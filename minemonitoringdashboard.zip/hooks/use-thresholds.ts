"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"

export interface Threshold {
  id: number
  sensor_id: string
  sensor_name: string
  threshold_value: number
  unit: string
  bench_id: string
  updated_at: string
}

export function useThresholds() {
  const [thresholds, setThresholds] = useState<Threshold[]>([])
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  const fetchThresholds = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/thresholds")
      const data = await response.json()

      if (data.success) {
        setThresholds(data.thresholds)
      }
    } catch (error) {
      console.error("Error fetching thresholds:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchThresholds()

    // Subscribe to realtime updates
    const channel = supabase
      .channel("thresholds-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "thresholds",
        },
        () => {
          fetchThresholds()
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  return { thresholds, loading, refetch: fetchThresholds }
}
