"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"

export interface Alert {
  id: string
  sensor_name: string
  sensor_value: number
  threshold: number
  severity: "normal" | "medium" | "critical"
  message: string
  read: boolean
  created_at: string
}

export function useAlerts() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    fetchAlerts()

    const channel = supabase
      .channel("alerts-channel")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "alerts",
        },
        (payload) => {
          console.log("[v0] New alert received:", payload)
          const newAlert = payload.new as Alert
          setAlerts((prev) => [newAlert, ...prev])

          if (newAlert.severity === "critical" && "Notification" in window) {
            if (Notification.permission === "granted") {
              new Notification("🚨 Critical Alert", {
                body: newAlert.message,
                icon: "/favicon.ico",
                tag: newAlert.id,
              })
            }
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  const fetchAlerts = async () => {
    try {
      const { data, error } = await supabase.from("alerts").select("*").order("created_at", { ascending: false })

      if (error) {
        console.error("[v0] Error fetching alerts:", error)
        return
      }

      setAlerts(data || [])
    } catch (error) {
      console.error("[v0] Error:", error)
    } finally {
      setLoading(false)
    }
  }

  const markAsRead = async (alertId: string) => {
    try {
      const { error } = await supabase.from("alerts").update({ read: true }).eq("id", alertId)

      if (error) {
        console.error("[v0] Error marking alert as read:", error)
        return
      }

      setAlerts((prev) => prev.map((alert) => (alert.id === alertId ? { ...alert, read: true } : alert)))
    } catch (error) {
      console.error("[v0] Error:", error)
    }
  }

  const markAllAsRead = async () => {
    try {
      const unreadAlertIds = alerts.filter((a) => !a.read).map((a) => a.id)

      if (unreadAlertIds.length === 0) return

      const { error } = await supabase.from("alerts").update({ read: true }).in("id", unreadAlertIds)

      if (error) {
        console.error("[v0] Error marking all as read:", error)
        return
      }

      setAlerts((prev) => prev.map((alert) => ({ ...alert, read: true })))
    } catch (error) {
      console.error("[v0] Error:", error)
    }
  }

  return {
    alerts,
    loading,
    unreadCount: alerts.filter((a) => !a.read).length,
    markAsRead,
    markAllAsRead,
    refreshAlerts: fetchAlerts,
  }
}
