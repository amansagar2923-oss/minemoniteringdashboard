# ABHAY.AI - Mining Monitoring Dashboard

**Advanced Mining Operations Monitoring & Safety System**

A comprehensive, AI-powered dashboard for real-time mining safety monitoring with ML-based risk prediction, Excel-based threshold management, and multi-channel alerting.

---

## 🚀 Features

### Core Functionality
- **Real-time Sensor Monitoring** - Track vibration, humidity, temperature, and pore pressure across multiple mine benches
- **AI Risk Prediction** - ML model with 94.8% accuracy for rockfall prediction
- **Dynamic Threshold Management** - Excel/CSV upload for bulk threshold updates
- **Multi-Channel Alerts** - Database storage, SMS, Email, and browser notifications
- **Multi-Language Support** - 10 languages including English, Hindi, Spanish, French, German, Chinese, Japanese, Arabic, Russian, and Portuguese
- **Dark Mode** - Full dark/light theme support

### Dashboard Pages
1. **Home** - Overview with weather data, model accuracy, and recent activity
2. **Status Panel** - Sensor input, real-time alerts, and risk zone visualization
3. **AI Model** - Threshold configuration and AI report generation
4. **ML Predictions** - Real-time ML prediction dashboard with confidence scores
5. **Excel Upload** - Bulk threshold management via CSV upload
6. **Notifications** - Alert history with unread indicators
7. **Settings** - Language selection and system configuration

---

## 📋 Prerequisites

- Node.js 18+
- Supabase account (already connected)
- Twilio account (optional, for SMS)
- Email account with app password (optional, for email alerts)

---

## 🔧 Setup Instructions

### 1. Database Setup

The system uses Supabase with three main tables. Execute these SQL scripts in order:

**Run the following scripts from the Scripts section:**

1. `001_create_alerts_table.sql` - Stores all sensor alerts
2. `002_create_thresholds_table.sql` - Manages dynamic sensor thresholds
3. `003_create_ml_predictions_table.sql` - Stores ML prediction history

To execute:
- Open the v0 interface
- Navigate to the Scripts section in the sidebar
- Run each script in numerical order
- Verify tables are created in your Supabase dashboard

### 2. Environment Variables

Configure the following in the **Vars** section of the in-chat sidebar:

**Supabase (Already Connected)**
\`\`\`
SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_anon_key
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
\`\`\`

**Twilio SMS (Optional)**
\`\`\`
TWILIO_ACCOUNT_SID=your_twilio_account_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_PHONE_NUMBER=+1234567890
ADMIN_PHONE_NUMBER=+1234567890
\`\`\`

**Email Notifications (Optional)**
\`\`\`
EMAIL_USER=your_email@gmail.com
EMAIL_PASSWORD=your_app_password
ADMIN_EMAIL=admin@yourcompany.com
\`\`\`

> **Note:** If SMS/Email credentials are not configured, the system will run in simulation mode and log notifications to the console.

### 3. Initial Deployment

1. Click **Publish** in the top-right corner
2. Deploy to Vercel
3. Access your deployed application
4. Visit the Excel Upload page to initialize thresholds

---

## 📊 System Architecture

\`\`\`
┌─────────────────────────────────────────────────────────┐
│                    Frontend (Next.js)                    │
├─────────────────────────────────────────────────────────┤
│  • Home Dashboard                                        │
│  • Status Panel (Sensor Input)                          │
│  • AI Model Configuration                               │
│  • ML Predictions Viewer                                │
│  • Excel Upload Manager                                 │
│  • Notifications Panel                                  │
│  • Settings                                             │
└────────────────┬────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────┐
│                  API Routes (Next.js)                    │
├─────────────────────────────────────────────────────────┤
│  • /api/alerts - Alert CRUD operations                  │
│  • /api/thresholds - Threshold management               │
│  • /api/excel/upload - CSV file processing              │
│  • /api/ml/predict - ML predictions                     │
│  • /api/notifications/sms - Twilio integration          │
│  • /api/notifications/email - Email notifications       │
└────────────────┬────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────┐
│              Database (Supabase PostgreSQL)              │
├─────────────────────────────────────────────────────────┤
│  • alerts - All sensor alerts with severity             │
│  • thresholds - Dynamic sensor thresholds               │
│  • ml_predictions - ML prediction history               │
│  • Real-time subscriptions enabled                      │
└─────────────────────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────┐
│              External Services (Optional)                │
├─────────────────────────────────────────────────────────┤
│  • Twilio - SMS Notifications                           │
│  • SMTP - Email Notifications                           │
│  • Browser - Push Notifications                         │
└─────────────────────────────────────────────────────────┘
\`\`\`

---

## 🎯 Usage Guide

### Adding Sensor Readings

1. Navigate to **Status Panel**
2. Select a bench (Bench 1-5)
3. Enter sensor values for:
   - Vibration (mm/s)
   - Humidity (%)
   - Temperature (°C)
   - Pore Pressure (kPa)
4. Click **Submit Reading**
5. System automatically:
   - Calculates risk severity
   - Runs ML prediction
   - Saves to database
   - Sends notifications (if configured)
   - Updates all dashboards in real-time

### Alert Severity Logic

\`\`\`
Value < 50% of Threshold  → Normal (Green)
Value ≥ 50% < Threshold   → Medium (Yellow)
Value ≥ Threshold         → Critical (Red)
\`\`\`

**Example:** If threshold is 50mm/s:
- 0-24mm/s → Normal (Green)
- 25-49mm/s → Medium (Yellow)
- 50+mm/s → Critical (Red)

### Uploading Thresholds via Excel

1. Go to **Excel Upload** page
2. Click **Download Template** to get the correct format
3. Edit the CSV file:
   \`\`\`csv
   sensor_id,sensor_name,threshold_value,unit,bench_id
   b1-s1,Vibration,50,mm/s,Bench 1
   b1-s2,Humidity,60,%,Bench 1
   \`\`\`
4. Click **Choose CSV File** and select your file
5. System automatically updates all thresholds
6. Changes reflect immediately across all pages

### Viewing ML Predictions

1. Navigate to **ML Predictions**
2. View recent predictions with:
   - Risk level (Normal/Medium/Critical)
   - Confidence score (0-100%)
   - AI-generated recommendations
   - Historical prediction data
3. Predictions update in real-time as sensors submit data

### Managing Notifications

1. Go to **Notifications** page
2. View all alerts with color-coded severity
3. Click on any notification to see details
4. Unread count shows in navbar badge
5. Visit page to auto-mark all as read

---

## 🧪 Testing the System

### Test 1: Normal Alert (Green)

1. Go to Status Panel
2. Enter value: **20** (threshold: 50)
3. Expected: Green alert, no modal popup
4. Verify: Shows in Notifications as "Normal"

### Test 2: Medium Alert (Yellow)

1. Go to Status Panel
2. Enter value: **40** (threshold: 50)
3. Expected: Yellow alert, no modal popup
4. Verify: Shows in Notifications as "Medium Risk"

### Test 3: Critical Alert (Red)

1. Go to Status Panel
2. Enter value: **60** (threshold: 50)
3. Expected: Red alert with modal popup
4. Verify:
   - Modal shows sensor details
   - Appears in Notifications as "Critical"
   - Navbar badge increments
   - Home page Recent Activity updates
   - SMS/Email sent (if configured)

### Test 4: Excel Upload

1. Download template from Excel Upload page
2. Change threshold values
3. Upload file
4. Verify: Thresholds update in AI Model page

### Test 5: Real-time Updates

1. Open dashboard in two browser tabs
2. Submit alert in Tab 1
3. Verify: Tab 2 updates automatically
4. Check: Navbar badge updates in both tabs

---

## 🔐 Security Best Practices

1. **Environment Variables** - Never commit credentials to version control
2. **Supabase RLS** - Enable Row Level Security policies on all tables
3. **API Routes** - Validate all inputs on server-side
4. **CORS** - Configure appropriate CORS policies for production
5. **Rate Limiting** - Implement rate limiting on API routes

---

## 📱 Multi-Language Support

The system supports 10 languages. Change language in **Settings** page:

- 🇬🇧 English
- 🇮🇳 Hindi (हिंदी)
- 🇪🇸 Spanish (Español)
- 🇫🇷 French (Français)
- 🇩🇪 German (Deutsch)
- 🇨🇳 Chinese (中文)
- 🇯🇵 Japanese (日本語)
- 🇸🇦 Arabic (العربية)
- 🇷🇺 Russian (Русский)
- 🇵🇹 Portuguese (Português)

All UI elements translate instantly without page reload.

---

## 🐛 Troubleshooting

### Alerts Not Saving
**Issue:** Alerts don't appear in Notifications
**Solution:**
1. Check Supabase connection in Vars section
2. Verify `001_create_alerts_table.sql` was executed
3. Check browser console for errors (F12)
4. Verify environment variables are set

### Excel Upload Failing
**Issue:** CSV upload returns error
**Solution:**
1. Ensure file format matches template exactly
2. Use comma-separated values (not semicolons)
3. Check sensor_id format: `b{num}-s{num}`
4. Verify all required columns are present

### SMS/Email Not Sending
**Issue:** No SMS or email notifications received
**Solution:**
1. Verify Twilio credentials in Vars section
2. Check email app password (not regular password)
3. Verify phone number format: `+1234567890`
4. Check API logs in browser console
5. System logs "SIMULATION MODE" if credentials missing

### Real-time Updates Not Working
**Issue:** Changes don't reflect in other tabs
**Solution:**
1. Check Supabase Realtime is enabled
2. Verify browser supports WebSockets
3. Check network tab for subscription errors
4. Refresh browser and try again

### ML Predictions Not Showing
**Issue:** ML Predictions page is empty
**Solution:**
1. Verify `003_create_ml_predictions_table.sql` was executed
2. Submit at least one sensor reading
3. Check `/api/ml/predict` endpoint is working
4. Verify thresholds exist in database

---

## 📈 Performance Optimization

- **Database Indexing** - All tables have indexes on frequently queried columns
- **Real-time Subscriptions** - Efficient Supabase channels for live updates
- **Code Splitting** - Next.js automatic code splitting
- **Image Optimization** - Next.js Image component for optimized loading
- **Caching** - API responses cached where appropriate

---

## 🛠️ Technology Stack

- **Framework:** Next.js 16 (App Router)
- **Language:** TypeScript
- **Styling:** Tailwind CSS v4
- **Database:** Supabase (PostgreSQL)
- **UI Components:** Radix UI + shadcn/ui
- **Charts:** Recharts
- **SMS:** Twilio
- **Email:** Nodemailer
- **Deployment:** Vercel

---

## 📚 Additional Documentation

- `ALERT_SYSTEM_SETUP.md` - Detailed alert system documentation
- `ML_EXCEL_SYSTEM_GUIDE.md` - ML model and Excel integration guide
- `scripts/` - SQL migration scripts

---

## 🤝 Support

For issues or questions:
1. Check browser console for error messages (F12)
2. Review troubleshooting section above
3. Verify all environment variables are set
4. Check Supabase dashboard for database issues
5. Review documentation files

---

## 📄 License

This project is proprietary software for mining operations monitoring.

---

## 🎉 Quick Start Checklist

- [ ] Execute all SQL scripts (001, 002, 003)
- [ ] Configure Supabase environment variables
- [ ] (Optional) Configure Twilio credentials
- [ ] (Optional) Configure email credentials
- [ ] Deploy to Vercel
- [ ] Upload initial thresholds via Excel Upload
- [ ] Test with sample sensor reading
- [ ] Verify notifications appear
- [ ] Test language switching
- [ ] Review ML predictions

---

**Built with ❤️ for Mining Safety**

**Version:** 3.2.1  
**Last Updated:** December 2025
